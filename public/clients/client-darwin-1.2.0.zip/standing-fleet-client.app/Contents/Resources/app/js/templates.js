this["Templates"] = this["Templates"] || {};
this["Templates"]["alert"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing;


  buffer += "<div class=\"event alert ";
  if (helper = helpers.type) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.type); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" onClick=\"EventList.alertClick('";
  if (helper = helpers.type) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.type); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "', '";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "')\">\r\n  <span class=\"text\"><i class=\"fa fa-"
    + escapeExpression((helper = helpers.ui_icon || (depth0 && depth0.ui_icon),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.type), options) : helperMissing.call(depth0, "ui_icon", (depth0 && depth0.type), options)))
    + "\"></i> ";
  if (helper = helpers.text) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.text); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</span>\r\n</div>\r\n";
  return buffer;
  });
this["Templates"]["event"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\r\n<div class=\"event ";
  if (helper = helpers.type) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.type); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" data-key=\"";
  if (helper = helpers.key) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.key); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\r\n  <i class=\"fa fa-"
    + escapeExpression((helper = helpers.ui_icon || (depth0 && depth0.ui_icon),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.type), options) : helperMissing.call(depth0, "ui_icon", (depth0 && depth0.type), options)))
    + "\"></i>\r\n  <span class=\"text\">";
  if (helper = helpers.text) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.text); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</span>\r\n  <div class=\"right\">\r\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.respondable), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    <span class=\"time\">";
  if (helper = helpers.time) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.time); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\r\n  </div>\r\n</div>\r\n";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\r\n    <span class=\"response\">\r\n      <a href=\"javascript:EventList.eventResponseClick('";
  if (helper = helpers.key) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.key); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "', 'y')\">Approve</a>\r\n      &nbsp;|&nbsp;\r\n      <a href=\"javascript:EventList.eventResponseClick('";
  if (helper = helpers.key) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.key); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "', 'n')\">Deny</a>\r\n    </span>\r\n    ";
  return buffer;
  }

  stack1 = helpers['if'].call(depth0, (depth0 && depth0.text), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n";
  return buffer;
  });
this["Templates"]["hostile"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  
  return "faded";
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\r\n      <a href=\"javascript:CCPEVE.showInfo(16159, ";
  if (helper = helpers.allianceId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.allianceId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + ");\">&lt;";
  if (helper = helpers.allianceName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.allianceName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "&gt;</a>\r\n    ";
  return buffer;
  }

function program5(depth0,data) {
  
  
  return "\r\n      No Alliance\r\n    ";
  }

function program7(depth0,data) {
  
  
  return "\r\n    <i class=\"fa fa-university\"></i> Docked\r\n    ";
  }

function program9(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n      ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.shipTypeId), {hash:{},inverse:self.program(12, program12, data),fn:self.program(10, program10, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    ";
  return buffer;
  }
function program10(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\r\n        <i class=\"fa fa-fighter-jet\"></i> <a href=\"javascript:CCPEVE.showInfo(";
  if (helper = helpers.shipTypeId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.shipTypeId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + ");\">";
  if (helper = helpers.shipType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.shipType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</a>\r\n      ";
  return buffer;
  }

function program12(depth0,data) {
  
  
  return "\r\n        Non Visual\r\n      ";
  }

  buffer += "<tr id=\"hostile-";
  if (helper = helpers.characterId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"hostile ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.is_faded), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\">\r\n  <td class=\"ship-icon\">";
  if (helper = helpers.shipIcon) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.shipIcon); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</td>\r\n  <td class=\"name\"><a href=\"javascript:CCPEVE.showInfo(1377, ";
  if (helper = helpers.characterId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + ");\">";
  if (helper = helpers.characterName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</a></td>\r\n  <td class=\"alliance\">\r\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.allianceName), {hash:{},inverse:self.program(5, program5, data),fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n  </td>\r\n  <td class=\"ship-type\" onClick=\"UIPanels.updateHostileDetailsPanel('";
  if (helper = helpers.characterId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "');\">\r\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.is_docked), {hash:{},inverse:self.program(9, program9, data),fn:self.program(7, program7, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n  </td>\r\n  <td class=\"system\"><a href=\"javascript:CCPEVE.showInfo(5,";
  if (helper = helpers.systemId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.systemId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + ");\">";
  if (helper = helpers.systemName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.systemName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</a></td>\r\n  <td class=\"reported-at\"><a title=\"Reported by ";
  if (helper = helpers.reporterName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.reporterName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">"
    + escapeExpression((helper = helpers.format_ts_short || (depth0 && depth0.format_ts_short),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.ts), options) : helperMissing.call(depth0, "format_ts_short", (depth0 && depth0.ts), options)))
    + "</a></td>\r\n  <td class=\"actions\">\r\n    <a title=\"Set Destination\" onClick=\"CCPEVE.setDestination(";
  if (helper = helpers.systemId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.systemId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + ")\"><i class=\"fa fa-map-marker\" title=\"Set Destination\"></i></a>\r\n    <a title=\"Killboard: ";
  if (helper = helpers.characterName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" target=\"_blank\" href=\"https://zkillboard.com/character/";
  if (helper = helpers.characterId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/\"><i class=\"fa fa-crosshairs\" title=\"Killboard\"></i></a>\r\n  </td>\r\n</tr>\r\n";
  return buffer;
  });
this["Templates"]["hud"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, helperMissing=helpers.helperMissing, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\r\n        <tr>\r\n          <td><i class=\"fa fa-";
  stack1 = (helper = helpers.hud_neighbor_status || (depth0 && depth0.hud_neighbor_status),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.id), (depth0 && depth0.name), options) : helperMissing.call(depth0, "hud_neighbor_status", (depth0 && depth0.id), (depth0 && depth0.name), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\"></i></td>\r\n          <td>";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n        </tr>\r\n        ";
  return buffer;
  }

function program3(depth0,data) {
  
  
  return "\r\n        <tr>\r\n          <td colspan=\"2\">No Connecting Systems</td>\r\n        </tr>\r\n        ";
  }

function program5(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\r\n        <li>\r\n          ";
  if (helper = helpers.characterName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1);
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.shipType), {hash:{},inverse:self.noop,fn:self.program(6, program6, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        </li>\r\n        ";
  return buffer;
  }
function program6(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += ": <i class=\"fa fa-fighter-jet\"></i> ";
  if (helper = helpers.shipType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.shipType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1);
  return buffer;
  }

function program8(depth0,data) {
  
  
  return "\r\n        <li>None reported</li>\r\n        ";
  }

function program10(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\r\n          <li><i class=\"fa fa-"
    + escapeExpression((helper = helpers.ui_icon || (depth0 && depth0.ui_icon),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.type), options) : helperMissing.call(depth0, "ui_icon", (depth0 && depth0.type), options)))
    + "\"></i> ";
  if (helper = helpers.type) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.type); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</li>\r\n        ";
  return buffer;
  }

function program12(depth0,data) {
  
  
  return "\r\n          <li>None reported</li>\r\n        ";
  }

function program14(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n    ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.system)),stack1 == null || stack1 === false ? stack1 : stack1.name), {hash:{},inverse:self.noop,fn:self.program(15, program15, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    ";
  return buffer;
  }
function program15(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\r\n    <h3>"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.system)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + ": ";
  if (helper = helpers.hostiles) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.hostiles); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " hostile";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.hostiles), {hash:{},inverse:self.noop,fn:self.program(16, program16, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += " ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.faded), {hash:{},inverse:self.noop,fn:self.program(18, program18, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</h3>\r\n    ";
  return buffer;
  }
function program16(depth0,data) {
  
  
  return "s";
  }

function program18(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "(";
  if (helper = helpers.faded) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.faded); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " faded)";
  return buffer;
  }

  buffer += "<div class=\"screen ";
  if (helper = helpers.status) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.status); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\r\n  <div class=\"console\">\r\n    <h2>";
  stack1 = (helper = helpers.hud_status_text || (depth0 && depth0.hud_status_text),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.status), options) : helperMissing.call(depth0, "hud_status_text", (depth0 && depth0.status), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</h2>\r\n\r\n    <div class=\"vicinity\">\r\n      <h3>Vicinity</h3>\r\n      <table>\r\n        <tbody>\r\n        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.vicinity), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        </tbody>\r\n      </table>\r\n    </div>\r\n\r\n    <div class=\"hostiles\">\r\n      <h3>Hostiles</h3>\r\n      <ul>\r\n        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.hostiles), {hash:{},inverse:self.program(8, program8, data),fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n      </ul>\r\n    </div>\r\n\r\n    <div class=\"advisories\">\r\n      <h3>Advisories</h3>\r\n      <ul>\r\n        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.advisories), {hash:{},inverse:self.program(12, program12, data),fn:self.program(10, program10, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n      </ul>\r\n    </div>\r\n\r\n    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.neighbors), {hash:{},inverse:self.noop,fn:self.program(14, program14, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n\r\n  </div>\r\n</div>\r\n";
  return buffer;
  });
this["Templates"]["jumpbridge_link_info"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<div class=\"jumpbridge-link-details\">\n  <h3>"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.source)),stack1 == null || stack1 === false ? stack1 : stack1.system)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + " <i class=\"fa fa-arrows-h\"></i> "
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.target)),stack1 == null || stack1 === false ? stack1 : stack1.system)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</h3>\n  \n  <h4>Locations</h4>\n  <dl>\n    <dt>"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.source)),stack1 == null || stack1 === false ? stack1 : stack1.system)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</dt>\n    <dd>"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.jumpbridge_data)),stack1 == null || stack1 === false ? stack1 : stack1.fromPlanet)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + " - "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.jumpbridge_data)),stack1 == null || stack1 === false ? stack1 : stack1.fromMoon)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</dd>\n    \n    <dt>"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.target)),stack1 == null || stack1 === false ? stack1 : stack1.system)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</dt>\n    <dd>"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.jumpbridge_data)),stack1 == null || stack1 === false ? stack1 : stack1.toPlanet)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + " - "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.jumpbridge_data)),stack1 == null || stack1 === false ? stack1 : stack1.toMoon)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</dd>\n  </dl>\n  \n  <h4>Details</h4>\n  <dl>\n    <dt>Owner</dt>\n    <dd>"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.jumpbridge_data)),stack1 == null || stack1 === false ? stack1 : stack1.owner)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</dd>\n\n    <dt>Password</dt>\n    <dd>"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.jumpbridge_data)),stack1 == null || stack1 === false ? stack1 : stack1.password)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</dd>\n\n    <dt>Designation</dt>\n    <dd>"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.jumpbridge_data)),stack1 == null || stack1 === false ? stack1 : stack1.route)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</dd>\n    \n    <dt>Distance</dt>\n    <dd>"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.jumpbridge_data)),stack1 == null || stack1 === false ? stack1 : stack1.distance)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "ly</dd>\n\n    <dt>Friendly</dt>\n    <dd>"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.jumpbridge_data)),stack1 == null || stack1 === false ? stack1 : stack1.friendly)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</dd>\n  </dl>  \n</div>\n";
  return buffer;
  });
this["Templates"]["map_legend"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<strong class=\"heading\">Map Legend</strong>\n<ul>\n  <li><span class=\"system-unknown current\">System</span>Current System</li>\n  <li><span class=\"system-unknown\">System</span>No Visual</li>\n  <li><span class=\"system-clear\">System</span>Clear</li>\n  <li><span class=\"system-warning\">System</span>Advisory Issued</li>\n  <li><span class=\"system-hostile\">System</span>Hostile</li>\n  <li><hr class=\"link\" /> System Gate\n  <li><hr class=\"link constellation\" /> Constellation Gate\n  <li><hr class=\"link region\" /> Regional Gate\n  <li><hr class=\"link wormhole\" /> Wormhole\n  <li><hr class=\"link jumpbridge\" /> Jumpbridge\n</ul>\n";
  });
this["Templates"]["member"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<tr class=\"member\" id=\"member-";
  if (helper = helpers.characterId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\r\n  <td class=\"name\"><a href=\"javascript:CCPEVE.showInfo(1377, ";
  if (helper = helpers.characterId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + ");\">";
  if (helper = helpers.characterName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</a></td>\r\n  <td class=\"actions\">\r\n    <a title=\"Start Conversation\" onClick=\"CCPEVE.startConversation(";
  if (helper = helpers.characterId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + ")\"><i class=\"fa fa-comment\" title=\"Start Conversation\"></i></a>\r\n    <a title=\"Killboard: ";
  if (helper = helpers.characterName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" target=\"_blank\" href=\"https://zkillboard.com/character/";
  if (helper = helpers.characterId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/\"><i class=\"fa fa-crosshairs\" title=\"Killboard\"></i></a>\r\n  </td>\r\n</tr>\r\n";
  return buffer;
  });
this["Templates"]["panel"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, functionType="function", self=this;

function program1(depth0,data) {
  
  
  return "<i class=\"close fa fa-times fa-2x\" onClick=\"UIPanels.hidePanel()\"></i>";
  }

function program3(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "<i class=\"fa fa-"
    + escapeExpression((helper = helpers.ui_icon || (depth0 && depth0.ui_icon),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.icon), options) : helperMissing.call(depth0, "ui_icon", (depth0 && depth0.icon), options)))
    + " fa-3x\"></i>";
  return buffer;
  }

function program5(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "<img src=\"/images/";
  if (helper = helpers.image) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.image); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" alt=\"Panel image\" />";
  return buffer;
  }

function program7(depth0,data) {
  
  
  return "<img id=\"logo\" src=\"/images/panel-logo.png\" alt=\"Standing Fleet\" />";
  }

function program9(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "<div class=\"text title\">";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</div>";
  return buffer;
  }

function program11(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\r\n    <div class=\"text ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.textclass), {hash:{},inverse:self.noop,fn:self.program(12, program12, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\">";
  if (helper = helpers.text) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.text); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</div>\r\n  ";
  return buffer;
  }
function program12(depth0,data) {
  
  var stack1, helper;
  if (helper = helpers.textclass) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.textclass); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  return escapeExpression(stack1);
  }

function program14(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n    <span class=\"error\">";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.error)),stack1 == null || stack1 === false ? stack1 : stack1.message)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</span>\r\n  ";
  return buffer;
  }

function program16(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n    <div class=\"form\">\r\n    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.formitems), {hash:{},inverse:self.noop,fn:self.program(17, program17, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    </div>\r\n  ";
  return buffer;
  }
function program17(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n      ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.input), {hash:{},inverse:self.noop,fn:self.program(18, program18, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n      ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.password), {hash:{},inverse:self.noop,fn:self.program(37, program37, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n      ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.textinput), {hash:{},inverse:self.noop,fn:self.program(40, program40, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n      ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.button), {hash:{},inverse:self.noop,fn:self.program(45, program45, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n      ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.checkbox), {hash:{},inverse:self.noop,fn:self.program(48, program48, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n      ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.submit), {hash:{},inverse:self.noop,fn:self.program(53, program53, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n      ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.group), {hash:{},inverse:self.noop,fn:self.program(56, program56, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    ";
  return buffer;
  }
function program18(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n      <div class=\"group\">\r\n        ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.input)),stack1 == null || stack1 === false ? stack1 : stack1.legend), {hash:{},inverse:self.noop,fn:self.program(19, program19, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        <input ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.input)),stack1 == null || stack1 === false ? stack1 : stack1.id), {hash:{},inverse:self.noop,fn:self.program(21, program21, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += " ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.input)),stack1 == null || stack1 === false ? stack1 : stack1.max), {hash:{},inverse:self.noop,fn:self.program(23, program23, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.input)),stack1 == null || stack1 === false ? stack1 : stack1['class']), {hash:{},inverse:self.noop,fn:self.program(25, program25, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "value=\"";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.input)),stack1 == null || stack1 === false ? stack1 : stack1.value)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\" type=";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.input)),stack1 == null || stack1 === false ? stack1 : stack1.hidden), {hash:{},inverse:self.program(29, program29, data),fn:self.program(27, program27, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += " ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.input)),stack1 == null || stack1 === false ? stack1 : stack1.readonly), {hash:{},inverse:self.noop,fn:self.program(31, program31, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += " ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.input)),stack1 == null || stack1 === false ? stack1 : stack1.onblur), {hash:{},inverse:self.noop,fn:self.program(33, program33, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += " ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.input)),stack1 == null || stack1 === false ? stack1 : stack1.label), {hash:{},inverse:self.noop,fn:self.program(35, program35, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "/>\r\n      </div>\r\n      ";
  return buffer;
  }
function program19(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "<span class=\"legend\">";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.input)),stack1 == null || stack1 === false ? stack1 : stack1.legend)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</span>";
  return buffer;
  }

function program21(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "id=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.input)),stack1 == null || stack1 === false ? stack1 : stack1.id)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" ";
  return buffer;
  }

function program23(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "max=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.input)),stack1 == null || stack1 === false ? stack1 : stack1.max)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" ";
  return buffer;
  }

function program25(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "class=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.input)),stack1 == null || stack1 === false ? stack1 : stack1['class'])),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" ";
  return buffer;
  }

function program27(depth0,data) {
  
  
  return "\"hidden\"";
  }

function program29(depth0,data) {
  
  
  return "\"text\"";
  }

function program31(depth0,data) {
  
  
  return "readonly=\"true\"";
  }

function program33(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "onblur=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.input)),stack1 == null || stack1 === false ? stack1 : stack1.onblur)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\"";
  return buffer;
  }

function program35(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "placeholder=\"";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.input)),stack1 == null || stack1 === false ? stack1 : stack1.label)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\"";
  return buffer;
  }

function program37(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n      <div class=\"group\">\r\n        ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.password)),stack1 == null || stack1 === false ? stack1 : stack1.legend), {hash:{},inverse:self.noop,fn:self.program(38, program38, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        <input id=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.password)),stack1 == null || stack1 === false ? stack1 : stack1.id)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" value=\"";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.password)),stack1 == null || stack1 === false ? stack1 : stack1.value)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\" type=\"password\" />\r\n      </div>\r\n      ";
  return buffer;
  }
function program38(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "<span class=\"legend\">";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.password)),stack1 == null || stack1 === false ? stack1 : stack1.legend)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</span>";
  return buffer;
  }

function program40(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n        ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.textinput)),stack1 == null || stack1 === false ? stack1 : stack1.legend), {hash:{},inverse:self.noop,fn:self.program(41, program41, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n        <textarea id=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.textinput)),stack1 == null || stack1 === false ? stack1 : stack1.id)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" class=\"textinput ";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.textinput)),stack1 == null || stack1 === false ? stack1 : stack1['class'])),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\" ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.textinput)),stack1 == null || stack1 === false ? stack1 : stack1.label), {hash:{},inverse:self.noop,fn:self.program(43, program43, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "></textarea>\r\n      ";
  return buffer;
  }
function program41(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "<span class=\"legend\">";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.textinput)),stack1 == null || stack1 === false ? stack1 : stack1.legend)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</span>";
  return buffer;
  }

function program43(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "placeholder=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.textinput)),stack1 == null || stack1 === false ? stack1 : stack1.label)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\"";
  return buffer;
  }

function program45(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n      <div class=\"group\">\r\n        <a ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.button)),stack1 == null || stack1 === false ? stack1 : stack1.link), {hash:{},inverse:self.noop,fn:self.program(46, program46, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += " target=\"_blank\" class=\"button ";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.button)),stack1 == null || stack1 === false ? stack1 : stack1['class'])),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\" onClick=\"";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.button)),stack1 == null || stack1 === false ? stack1 : stack1.onClick)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\">";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.button)),stack1 == null || stack1 === false ? stack1 : stack1.text)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</a>\r\n      </div>\r\n      ";
  return buffer;
  }
function program46(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "href=\"";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.button)),stack1 == null || stack1 === false ? stack1 : stack1.link)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\"";
  return buffer;
  }

function program48(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n      <div class=\"group\">\r\n        <input type=\"checkbox\" id=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.checkbox)),stack1 == null || stack1 === false ? stack1 : stack1.id)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.checkbox)),stack1 == null || stack1 === false ? stack1 : stack1.checked), {hash:{},inverse:self.noop,fn:self.program(49, program49, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += " ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.checkbox)),stack1 == null || stack1 === false ? stack1 : stack1.onclick), {hash:{},inverse:self.noop,fn:self.program(51, program51, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += ">\r\n        <span class=\"label\">";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.checkbox)),stack1 == null || stack1 === false ? stack1 : stack1.label)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</span>\r\n      </div>\r\n      ";
  return buffer;
  }
function program49(depth0,data) {
  
  
  return "checked";
  }

function program51(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "onclick=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.checkbox)),stack1 == null || stack1 === false ? stack1 : stack1.onclick)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\"";
  return buffer;
  }

function program53(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n      <div class=\"submit\">\r\n        <a ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.submit)),stack1 == null || stack1 === false ? stack1 : stack1.link), {hash:{},inverse:self.noop,fn:self.program(54, program54, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += " target=\"_blank\" class=\"button\" onClick=\"";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.submit)),stack1 == null || stack1 === false ? stack1 : stack1.onClick)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\">";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.submit)),stack1 == null || stack1 === false ? stack1 : stack1.text)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</a>\r\n      </div>\r\n      ";
  return buffer;
  }
function program54(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "href=\"";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.submit)),stack1 == null || stack1 === false ? stack1 : stack1.link)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\"";
  return buffer;
  }

function program56(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n        <div class=\"group\">\r\n          ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.group)),stack1 == null || stack1 === false ? stack1 : stack1.legend), {hash:{},inverse:self.noop,fn:self.program(57, program57, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n          <div class=\"group-items\">\r\n            ";
  stack1 = helpers.each.call(depth0, ((stack1 = (depth0 && depth0.group)),stack1 == null || stack1 === false ? stack1 : stack1.formitems), {hash:{},inverse:self.noop,fn:self.program(59, program59, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n          </div>\r\n        </div>\r\n      ";
  return buffer;
  }
function program57(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "<span class=\"legend\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.group)),stack1 == null || stack1 === false ? stack1 : stack1.legend)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</span>";
  return buffer;
  }

function program59(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n              ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.checkbox), {hash:{},inverse:self.noop,fn:self.program(60, program60, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n            ";
  return buffer;
  }
function program60(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n              <div class=\"item\">\r\n                <input type=\"checkbox\" id=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.checkbox)),stack1 == null || stack1 === false ? stack1 : stack1.id)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.checkbox)),stack1 == null || stack1 === false ? stack1 : stack1.checked), {hash:{},inverse:self.noop,fn:self.program(49, program49, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += " ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.checkbox)),stack1 == null || stack1 === false ? stack1 : stack1.onclick), {hash:{},inverse:self.noop,fn:self.program(51, program51, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += ">\r\n                <span class=\"label\">";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.checkbox)),stack1 == null || stack1 === false ? stack1 : stack1.label)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</span>\r\n              </div>\r\n              ";
  return buffer;
  }

function program62(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\r\n    <div class=\"text footer\">";
  if (helper = helpers.footer) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.footer); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</div>\r\n  ";
  return buffer;
  }

  buffer += "<div class=\"panel ";
  if (helper = helpers.type) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.type); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\r\n  <div class=\"header\">\r\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.closeable), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.icon), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.image), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.logo), {hash:{},inverse:self.noop,fn:self.program(7, program7, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.title), {hash:{},inverse:self.noop,fn:self.program(9, program9, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n  </div>\r\n  <div class=\"content\">\r\n  ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.text), {hash:{},inverse:self.noop,fn:self.program(11, program11, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n  ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.error), {hash:{},inverse:self.noop,fn:self.program(14, program14, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n  ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.formitems), {hash:{},inverse:self.noop,fn:self.program(16, program16, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n  ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.footer), {hash:{},inverse:self.noop,fn:self.program(62, program62, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n  </div>\r\n</div>\r\n";
  return buffer;
  });
this["Templates"]["report"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\r\n  <i class=\"fa fa-check\"></i>\r\n  <span class=\"text\">\r\n    ";
  if (helper = helpers.systemName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.systemName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " reported clear by ";
  if (helper = helpers.reporterName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.reporterName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\r\n  </span>  \r\n  ";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\r\n  <i class=\"fa fa-crosshairs\"></i>\r\n  <span class=\"text\">\r\n    "
    + escapeExpression((helper = helpers.reported || (depth0 && depth0.reported),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.pilots), options) : helperMissing.call(depth0, "reported", (depth0 && depth0.pilots), options)))
    + " reported in ";
  if (helper = helpers.systemName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.systemName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " by ";
  if (helper = helpers.reporterName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.reporterName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\r\n  </span>  \r\n  ";
  return buffer;
  }

  buffer += "<div class=\"event ";
  if (helper = helpers.type) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.type); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" data-key=\"";
  if (helper = helpers.key) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.key); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\r\n  ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.clear), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n  <div class=\"right\">\r\n    <span class=\"time\">";
  if (helper = helpers.time) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.time); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\r\n  </div>\r\n</div>\r\n";
  return buffer;
  });
this["Templates"]["scan"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\r\n      <div class=\"result\">\r\n        <span class=\"ship-class\">";
  if (helper = helpers.count) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.count); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "x <b>";
  if (helper = helpers.shipClass) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.shipClass); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</b></span>\r\n      </div>\r\n    ";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\r\n      <div class=\"result\">\r\n        <span class=\"ship-type\" onclick=\"ScanList.toggleCollapse(this)\">";
  if (helper = helpers.count) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.count); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "x <b>";
  if (helper = helpers.shipType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.shipType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</b></span>\r\n\r\n        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.details), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n      </div>\r\n    ";
  return buffer;
  }
function program4(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\r\n        <div class=\"details-container collapsible\">\r\n          <span class=\"ship-name\">";
  if (helper = helpers.shipName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.shipName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\r\n          <span class=\"distance\">";
  if (helper = helpers.distance) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.distance); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\r\n        </div>\r\n        ";
  return buffer;
  }

  buffer += "<div class=\"scan\">\r\n  <table class=\"description\" onclick=\"ScanList.toggleCollapse(this);\">\r\n    <tr>\r\n      <td class=\"reported-by\"><a href=\"javascript:CCPEVE.showInfo(1377, ";
  if (helper = helpers.reporterId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.reporterId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + ");\">";
  if (helper = helpers.reporterName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.reporterName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</a> shared scan results</td>\r\n      <td class=\"system\"><a href=\"javascript:CCPEVE.showInfo(5,";
  if (helper = helpers.systemId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.systemId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + ");\">";
  if (helper = helpers.systemName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.systemName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</a></td>\r\n      <td class=\"actions\">\r\n        <a title=\"Permalink\" target=\"_blank\" href=\"/scans/";
  if (helper = helpers._id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0._id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/\"><i class=\"fa fa-external-link-square\" title=\"Scan Permalink\"></i></a>\r\n      </td>\r\n      <td class=\"reported-at\">";
  if (helper = helpers.time) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.time); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</td>\r\n    </tr>\r\n  </table>\r\n  <div class=\"results-container collapsible\">\r\n    <ul class=\"actions\">\r\n      <li><a class=\"btn\" onclick=\"scanFilter(this, 'grid');\">On Grid</a></li>\r\n      <li><a class=\"btn\" onclick=\"scanFilter(this, 'offgrid');\">Off Grid</a></li>\r\n    </ul>\r\n    <div class=\"scan-classes\">\r\n    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.shipClasses), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    </div>\r\n    <div class=\"type-classes\">\r\n    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.shipTypes), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    </div>\r\n  </div>\r\n</div>\r\n";
  return buffer;
  });
this["Templates"]["start"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, functionType="function", self=this;

function program1(depth0,data) {
  
  
  return "<i class=\"close fa fa-times fa-2x\" onClick=\"UIPanels.hidePanel()\"></i>";
  }

function program3(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "<i class=\"fa fa-"
    + escapeExpression((helper = helpers.ui_icon || (depth0 && depth0.ui_icon),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.icon), options) : helperMissing.call(depth0, "ui_icon", (depth0 && depth0.icon), options)))
    + " fa-3x\"></i>";
  return buffer;
  }

function program5(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "<img src=\"/images/";
  if (helper = helpers.image) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.image); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" alt=\"Panel image\" />";
  return buffer;
  }

function program7(depth0,data) {
  
  
  return "<img id=\"logo\" src=\"/images/panel-logo.png\" alt=\"Standing Fleet\" />";
  }

function program9(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "<div class=\"text title\">";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</div>";
  return buffer;
  }

function program11(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n      <tr>\n        <td>\n          <a href=\"/";
  if (helper = helpers.key) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.key); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" title=\"";
  if (helper = helpers.key) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.key); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.name), {hash:{},inverse:self.program(14, program14, data),fn:self.program(12, program12, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n          </a>\n        </td>\n        <td>";
  if (helper = helpers.description) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.description); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</td>\n        <td>\n          ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.has_password), {hash:{},inverse:self.noop,fn:self.program(16, program16, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n          "
    + escapeExpression((helper = helpers.format_ts || (depth0 && depth0.format_ts),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.ts), options) : helperMissing.call(depth0, "format_ts", (depth0 && depth0.ts), options)))
    + "</td>\n      </tr>\n      ";
  return buffer;
  }
function program12(depth0,data) {
  
  var stack1, helper;
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  return escapeExpression(stack1);
  }

function program14(depth0,data) {
  
  var stack1, helper;
  if (helper = helpers.key) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.key); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  return escapeExpression(stack1);
  }

function program16(depth0,data) {
  
  
  return "<i class=\"fa fa-lock\"></i>";
  }

function program18(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n  <div class=\"text footer\">";
  if (helper = helpers.footer) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.footer); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</div>\n  ";
  return buffer;
  }

  buffer += "<div class=\"panel ";
  if (helper = helpers.type) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.type); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n  <div class=\"header\">\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.closeable), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.icon), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.image), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.logo), {hash:{},inverse:self.noop,fn:self.program(7, program7, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.title), {hash:{},inverse:self.noop,fn:self.program(9, program9, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n  </div>\n  \n  <!-- <a class=\"button submit-create\" onclick=\"UIPanels.showCreatePanel()\">Create Fleet</a> -->\n  \n  <h2>Current Fleets</h2>\n  <table>\n    <thead>\n      <tr>\n        <th>Name</th>\n        <th>Description</th>\n        <th>Formed</th>\n      </tr>\n    </thead>\n    <tbody>\n      ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.fleets), {hash:{},inverse:self.noop,fn:self.program(11, program11, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </tbody>\n  </table>  \n  \n  <a target=\"_blank\" class=\"button submit-leave\" onclick=\"leaveFleet()\">Leave Fleet</a>\n\n  ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.footer), {hash:{},inverse:self.noop,fn:self.program(18, program18, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</div>\n";
  return buffer;
  });
this["Templates"]["system_info"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <dt>WH Class</dt>\n    <dd class=\"wormhole-class\">C";
  if (helper = helpers.wormhole_class) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.wormhole_class); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n    \n    ";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <dt>Security Class</dt>\n    <dd class=\"security-class\">";
  if (helper = helpers.security_class) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.security_class); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n\n    <dt>Security Level</dt>\n    <dd class=\"security-level\">";
  if (helper = helpers.security) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.security); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n    ";
  return buffer;
  }

function program5(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    <dt>Hostiles</dt>\n    <dd class=\"hostiles\">\n      ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.hostiles), {hash:{},inverse:self.noop,fn:self.program(6, program6, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </dd>\n    ";
  return buffer;
  }
function program6(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n        <div class=\"hostile\" onClick=\"UIPanels.updateHostileDetailsPanel('";
  if (helper = helpers.characterId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "');\">\n          ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.is_faded), {hash:{},inverse:self.program(9, program9, data),fn:self.program(7, program7, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </div>\n      ";
  return buffer;
  }
function program7(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n          <i class=\"fa fa-clock-o\" title=\"Faded\"></i> ";
  if (helper = helpers.characterName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n          ";
  return buffer;
  }

function program9(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n          <i class=\"fa fa-fighter-jet\" title=\"Active\"></i> ";
  if (helper = helpers.characterName) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.characterName); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n          ";
  return buffer;
  }

function program11(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    <dt>Gates</dt>\n    <dd class=\"gates\">\n      <ul>\n        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.jumps), {hash:{},inverse:self.noop,fn:self.program(12, program12, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n      </ul>\n    </dd>\n    ";
  return buffer;
  }
function program12(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n        <li><i class=\"fa fa-chevron-right\"></i>";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</li>\n        ";
  return buffer;
  }

function program14(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    <dt>Advisories<dt>\n    <dd class=\"advisories\">\n      <ul>\n        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.active_advisories), {hash:{},inverse:self.noop,fn:self.program(15, program15, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n      </ul>\n    </dd>\n    ";
  return buffer;
  }
function program15(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n        <li><i class=\"fa fa-"
    + escapeExpression((helper = helpers.ui_icon || (depth0 && depth0.ui_icon),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.type), options) : helperMissing.call(depth0, "ui_icon", (depth0 && depth0.type), options)))
    + "\"></i> ";
  if (helper = helpers.type) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.type); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</li>\n        ";
  return buffer;
  }

function program17(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n  <h4 class=\"report-advisory\">Report Advisory</h4>\n  ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.advisories), {hash:{},inverse:self.noop,fn:self.program(18, program18, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n  ";
  return buffer;
  }
function program18(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n  <a class=\"btn ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.present), {hash:{},inverse:self.noop,fn:self.program(19, program19, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\" onclick=\"reportAdvisory(this, '";
  if (helper = helpers.systemId) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.systemId); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "', '";
  if (helper = helpers.type) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.type); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "')\" title=\"";
  if (helper = helpers.type) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.type); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"><i class=\"fa fa-"
    + escapeExpression((helper = helpers.ui_icon || (depth0 && depth0.ui_icon),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.type), options) : helperMissing.call(depth0, "ui_icon", (depth0 && depth0.type), options)))
    + "\"></i></a>\n  ";
  return buffer;
  }
function program19(depth0,data) {
  
  
  return "present";
  }

  buffer += "<div class=\"details\">\n  <h4>Solar System Details</h4>\n  <dl>\n    <dt>System</dt>\n    <dd class=\"system\">";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n\n    <dt>Region</dt>\n    <dd class=\"region\">";
  if (helper = helpers.region) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.region); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.wormhole_class), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    \n    <dt>Last Report</dt>\n    <dd class=\"last-report\">";
  if (helper = helpers.last_report) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.last_report); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</dd>\n\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.hostiles), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    \n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.jumps), {hash:{},inverse:self.noop,fn:self.program(11, program11, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.active_advisories), {hash:{},inverse:self.noop,fn:self.program(14, program14, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n  </dl>\n\n  ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.allow_report), {hash:{},inverse:self.noop,fn:self.program(17, program17, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n  <h4 class=\"external\">External Resources</h4>  \n  <a class=\"btn\" target=\"_blank\" href=\"http://evemaps.dotlan.net/map/";
  if (helper = helpers.region) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.region); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "/";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "#const\">\n    Dotlan\n    <i class=\"fa fa-external-link-square\"></i>\n  </a>\n</div>\n";
  return buffer;
  });
this["Templates"]["wormhole_link_info"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    <dd class=\"signature\">"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.signature)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</dd>\n    ";
  return buffer;
  }

function program3(depth0,data) {
  
  
  return "\n    <dd class=\"signature\">Not Scanned</dd>\n    ";
  }

function program5(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    <dt>Jump Type</dt>\n    <dd class=\"code\">"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.code)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</dd>\n    ";
  return buffer;
  }

function program7(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    <dd class=\"signature\">"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.link_b)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.signature)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</dd>\n    ";
  return buffer;
  }

function program9(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    <dt>Jump Type</dt>\n    <dd class=\"code\">"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.link_b)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.code)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</dd>\n    ";
  return buffer;
  }

function program11(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    <dt>Lifespan</dt>\n    <dd class=\"lifespan\">"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.lifespan_estimate)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</dd>\n    ";
  return buffer;
  }

function program13(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n    <dt>Jump Limit</dt>\n    <dd class=\"jump-mass\">"
    + escapeExpression((helper = helpers.add_commas || (depth0 && depth0.add_commas),options={hash:{},data:data},helper ? helper.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.jump_mass), options) : helperMissing.call(depth0, "add_commas", ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.jump_mass), options)))
    + " KG</dd>\n    ";
  return buffer;
  }

function program15(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n    <dt>Mass Left</dt>\n    <dd class=\"mass\">"
    + escapeExpression((helper = helpers.add_commas || (depth0 && depth0.add_commas),options={hash:{},data:data},helper ? helper.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.mass_total), options) : helperMissing.call(depth0, "add_commas", ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.mass_total), options)))
    + " KG</dd>\n    ";
  return buffer;
  }

function program17(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    <dt>Allowed Ships</dt>\n    <dd class=\"permitted-ships\">\n      ";
  stack1 = helpers.each.call(depth0, ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.permitted_ships), {hash:{},inverse:self.noop,fn:self.program(18, program18, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </dd>\n    ";
  return buffer;
  }
function program18(depth0,data) {
  
  var buffer = "";
  buffer += "\n      <img src=\"/images/ship-icons/"
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + ".png\" title=\""
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "\" alt=\""
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "\" />\n      ";
  return buffer;
  }

function program20(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    <dt>Reported By</dt>\n    <dd><a href=\"javascript:CCPEVE.showInfo(1377, "
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.reporterId)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + ");\">"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.reporterName)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</a></dd>\n    ";
  return buffer;
  }

function program22(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n    <h4>Update Link Actions</h4>\n    ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.clear_only), {hash:{},inverse:self.noop,fn:self.program(23, program23, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    <a class=\"btn btn-danger\" onclick=\"updateWormholeLink(this, '"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.source)),stack1 == null || stack1 === false ? stack1 : stack1.system)),stack1 == null || stack1 === false ? stack1 : stack1.id)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "', '"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.target)),stack1 == null || stack1 === false ? stack1 : stack1.system)),stack1 == null || stack1 === false ? stack1 : stack1.id)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "', 'Wormhole collapsed')\" title=\"Close\">\n      <i class=\"fa fa-"
    + escapeExpression((helper = helpers.ui_icon || (depth0 && depth0.ui_icon),options={hash:{},data:data},helper ? helper.call(depth0, "close", options) : helperMissing.call(depth0, "ui_icon", "close", options)))
    + "\"></i> Clear\n    </a>  \n  ";
  return buffer;
  }
function program23(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n    <a class=\"btn btn-info\" onclick=\"UIPanels.updateWormholeLinkPanel(this, '"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.source)),stack1 == null || stack1 === false ? stack1 : stack1.system)),stack1 == null || stack1 === false ? stack1 : stack1.id)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "', '"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.target)),stack1 == null || stack1 === false ? stack1 : stack1.system)),stack1 == null || stack1 === false ? stack1 : stack1.id)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "')\" title=\"Update\">\n      <i class=\"fa fa-"
    + escapeExpression((helper = helpers.ui_icon || (depth0 && depth0.ui_icon),options={hash:{},data:data},helper ? helper.call(depth0, "info", options) : helperMissing.call(depth0, "ui_icon", "info", options)))
    + "\"></i> Update\n    </a>\n    ";
  return buffer;
  }

  buffer += "<div class=\"wormhole-link-details\">\n  <h4>"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.source)),stack1 == null || stack1 === false ? stack1 : stack1.system)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "<i class=\"fa fa-long-arrow-right\"></i> "
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.link_b)),stack1 == null || stack1 === false ? stack1 : stack1.source)),stack1 == null || stack1 === false ? stack1 : stack1.system)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</h4>\n  <dl>\n    <dt>Signature ID</dt>\n    ";
  stack1 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.signature), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    \n    ";
  stack1 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.code), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n  </dl>\n  \n  <h4>"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.link_b)),stack1 == null || stack1 === false ? stack1 : stack1.source)),stack1 == null || stack1 === false ? stack1 : stack1.system)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "<i class=\"fa fa-long-arrow-right\"></i> "
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.source)),stack1 == null || stack1 === false ? stack1 : stack1.system)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</h4>\n  <dl>\n    <dt>Signature ID</dt>\n    ";
  stack1 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.link_b)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.signature), {hash:{},inverse:self.program(3, program3, data),fn:self.program(7, program7, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    \n    ";
  stack1 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.link_b)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.code), {hash:{},inverse:self.noop,fn:self.program(9, program9, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n  </dl>\n  \n  <h4>Jump Estimates</h4>\n  <dl>\n    ";
  stack1 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.lifespan_estimate), {hash:{},inverse:self.noop,fn:self.program(11, program11, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    \n    ";
  stack1 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.jump_mass), {hash:{},inverse:self.noop,fn:self.program(13, program13, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    \n    ";
  stack1 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.mass_total), {hash:{},inverse:self.noop,fn:self.program(15, program15, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n    ";
  stack1 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.mass_total), {hash:{},inverse:self.noop,fn:self.program(17, program17, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    \n    <dt>Expires</dt>\n    <dd class=\"expires-on\">"
    + escapeExpression((helper = helpers.format_ts || (depth0 && depth0.format_ts),options={hash:{},data:data},helper ? helper.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.expires_on), options) : helperMissing.call(depth0, "format_ts", ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.expires_on), options)))
    + "</dd>\n    \n    <dt>Last Updated</dt>\n    <dd class=\"updated-at\">"
    + escapeExpression((helper = helpers.format_ts || (depth0 && depth0.format_ts),options={hash:{},data:data},helper ? helper.call(depth0, ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.updated_at), options) : helperMissing.call(depth0, "format_ts", ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.updated_at), options)))
    + "</dd>\n    \n    ";
  stack1 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.link_a)),stack1 == null || stack1 === false ? stack1 : stack1.wormhole_data)),stack1 == null || stack1 === false ? stack1 : stack1.reporterId), {hash:{},inverse:self.noop,fn:self.program(20, program20, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n  </dl>\n  \n  ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.read_only), {hash:{},inverse:self.noop,fn:self.program(22, program22, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</div>\n";
  return buffer;
  });
this["Templates"]["wormhole_update_panel"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, self=this, functionType="function";

function program1(depth0,data) {
  
  
  return "<i class=\"close fa fa-times fa-2x\" onClick=\"UIPanels.hidePanel()\"></i>";
  }

function program3(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "<i class=\"fa fa-"
    + escapeExpression((helper = helpers.ui_icon || (depth0 && depth0.ui_icon),options={hash:{},data:data},helper ? helper.call(depth0, (depth0 && depth0.icon), options) : helperMissing.call(depth0, "ui_icon", (depth0 && depth0.icon), options)))
    + " fa-3x\"></i>";
  return buffer;
  }

  buffer += "<div class=\"panel wormhole-update\">\r\n  <div class=\"header\">\r\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.closeable), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.icon), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n    <div class=\"text title\">Update Wormhole Link</div>\r\n  </div>\r\n  <div class=\"content\">\r\n    <div class=\"form\">\r\n      <input id=\"to\" type=\"hidden\" value=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.to)),stack1 == null || stack1 === false ? stack1 : stack1.id)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" />\r\n      <input id=\"from\" type=\"hidden\" value=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.from)),stack1 == null || stack1 === false ? stack1 : stack1.id)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" />\r\n\r\n      <span class=\"legend\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.from)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + " <i class=\"fa fa-long-arrow-right\"></i> "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.to)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</span>\r\n      <div class=\"group inline\">\r\n        <label for=\"sig-a\" autofocus>Signature ID</label>\r\n        <input id=\"sig-a\" max=\"7\" type=\"text\" />\r\n      </div>\r\n      \r\n      <div class=\"group inline\">\r\n        <label for=\"type-a\">Wormhole Code</label>\r\n        <input id=\"type-a\" max=\"4\" type=\"text\" />\r\n      </div>\r\n      \r\n      <span class=\"legend\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.to)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + " <i class=\"fa fa-long-arrow-right\"></i> "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.from)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</span>\r\n      <div class=\"group inline\">\r\n        <label for=\"sig-b\">Signature ID</label>\r\n        <input id=\"sig-b\" max=\"7\" type=\"text\" />\r\n      </div>\r\n      \r\n      <div class=\"group inline\">\r\n        <label for=\"type-b\">Wormhole Code</label>\r\n        <input id=\"type-b\" max=\"4\" type=\"text\" />\r\n      </div>\r\n\r\n      <span class=\"legend\">Wormhole Info Text</span>\r\n      <textarea id=\"wormhole-info\" class=\"textinput wormhole-info\"></textarea>\r\n\r\n      <div class=\"submit\">\r\n        <a target=\"_blank\" class=\"button\" onClick=\"updateWormholeLink(this, "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.from)),stack1 == null || stack1 === false ? stack1 : stack1.id)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + ", "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.to)),stack1 == null || stack1 === false ? stack1 : stack1.id)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + ")\">Update Jump Link</a>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n";
  return buffer;
  });