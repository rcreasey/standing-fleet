function pollClipboard() {
  var cb = require('clipboard');

  UI.startSpin();
  setTimeout(function() {
    if (Data.state.poll.clipboard) {
      var text = cb.readText();
      if (text) {
        var clipboard = document.getElementById('clipboard');
        var event = {time: Util.getTime(), type: 'sourcedClipboard', data: text};
        cb.clear();

        var renderedEvent = $(Templates.event({time: event.time, text: event.data}));
        Data.ui.clipboard_list.prepend(renderedEvent);
        Data.state.datasources.local.getClient().publish('/events', event);
      }
      UI.stopSpin();
    }

    pollClipboard();

  }, Data.state.poll.loop);
}

var path = require('path');

var Data = {
  config: {
    domain: 'https://standing-fleet.apps.goonswarm.org/',
    apiUrl: '/api/fleet',
    alertStay: 5000,
    maxEvents: 20,
    uiSpeed: 400,
    local_dataport: 44444,
    log: 'console'
  },

  state: {
    alertCount: 0,
    dimmed: false,
    poll: {
      loop: 15000,
      clipboard: false,
      logs: true
    },
    datasources: {
      local: null,
      logs: {
        handles: [],
        path: {
          win: path.join(process.env['USERPROFILE'] || '','Documents','EVE','logs','Chatlogs'),
          darwin: path.join(process.env['HOME'] || '','Library','Application Support','EVE Online','p_drive','User','My Documents','EVE','logs','Chatlogs')
        },
        channels: {
          "DEK.CFC": true,
          "BRN.CFC": false,
          "CR.CFC": false,
          "CRS.CFC": false,
          "DET.CFC": false,
          "DPB.CFC": false,
          "FTN.CFC": false,
          "GEM.CFC": false,
          "IMM.CFC": false,
          "KAL.CFC": false,
          "PBF.CFC": false,
          "QUE.CFC": false,
          "SYND.CFC": false,
          "tenal_int": false,
          "TRIB.CFC": false,
          "VALE.CFC": false,
          "VNL.CFC": false,
          "EC_Gate.CFC": false,
          "MO_Gate.CFC": false,
          "P3_Gate.CFC": false
        }
      }
    }
  },

  build_ui: function() {
    return {
      logo: $('#top-logo'),
      alertContainer: $('#alert-container'),
      contentWrapper: $('#content-wrapper'),
      dim: $('#dim'),

      topMenu: $('#top-menu'),
      topMenu_clipboard: $('#top-menu-clipboard'),
      topMenu_logs: $('#top-menu-logs'),

      bottomMenu: $('#bottom-menu'),
      bottomMenu_spinner: $('#bottom-menu-spinner'),
      bottomMenu_menu: $('#bottom-menu-menu'),

      clipboard: $('#clipboard'),
      clipboard_list: $('#clipboard > .list'),
      logs: $('#logs'),
      logs_list: $('#logs > .list')
    };
  },

  build_templates: function() {
    return {
      alert: Templates.alert,
      event: Templates.event,
      report: Templates.report,
      panel: Templates.panel
    };
  }
};

var http = require('http')
  , faye = require('faye')
  , moment = require('moment')

  
$(function () {
  initializeClient();
});

function initializeClient() {
  log('Client Init...');
  Data.ui = Data.build_ui();
  Data.templates = Data.build_templates();

  log('Starting Server...');
  var server = http.createServer();
  Data.state.datasources.local = new faye.NodeAdapter({mount: '/', timeout: 45});

  Data.state.datasources.local.attach(server);
  server.listen(Data.config.local_dataport);

  UI.tabClick('logs');
  UI.stopSpin();
  UI.registerEventHandlers();
  UI.unDim();

  log('Begin Polling...');
  pollClipboard();
  pollLogs();
};

var fs = require('fs')
  , path = require('path')
  , tail = require('file-tail')

function pollLogs() {
  if (!Data.state.poll.logs) return;

  var log_dir = (/^win/.test(process.platform)) ? Data.state.datasources.logs.path.win : Data.state.datasources.logs.path.darwin;
  var channels = [];

  for (var channel in Data.state.datasources.logs.channels) {
    if (Data.state.datasources.logs.channels[channel]) channels.push(channel);
  }

  if (!channels.length) {
    log('No logs to parse');
    var renderedEvent = $(Templates.event({'time': Util.getTime(), type: 'error', text: 'No logs to parse.  Have you joined an intel channel today?' }));
    Data.ui.logs_list.prepend(renderedEvent);
    return;
  }

  var filename_match = '(' + channels.join('|') + ')_';
  filename_match += moment().utc().format('YYYYMMDD');
  filename_match += '_\\d+.txt';

  fs.readdir(log_dir, function(err, list) {
    if (err) {
      var renderedEvent = $(Templates.event({'time': Util.getTime(), type: 'error', text: 'Unable to poll logs: ' + err }));
      Data.ui.logs_list.prepend(renderedEvent);
      return;
    }

    var regex = new RegExp(filename_match);
    list.forEach( function(file) {
      if (regex.test(file)) {
        var renderedEvent = $(Templates.event({'time': Util.getTime(), text: 'Watching ' + file }));
        Data.ui.logs_list.prepend(renderedEvent);

        t = new tail.startTailing(path.join(log_dir, file));
        t.on('line', function(line) {
          if (line.length === 1) return;

          processLine(line, function(event) {
            if (!event) return;

            var renderedEvent = $(Templates.report(event.data));
            Data.ui.logs_list.prepend(renderedEvent);
            Data.state.datasources.local.getClient().publish('/events', event);
          });
        });

        Data.state.datasources.logs.handles.push( t );
      }
    });
  });

}

function resetLogPolling() {
  log('Clearing log handles...');
  while (Data.state.datasources.logs.handles.length) {
    var handle = Data.state.datasources.logs.handles.pop();
    handle.stop();
    delete handle;
  }

  pollLogs();
}

var etree = require('elementtree')
  , https = require('https')
  , request = require('request')
  , _ = require('lodash')
  , encoding = require('encoding')

var Dict = function() {
  "use strict";
  this._root = {};
};

Dict.prototype = {
  /**
   * @param {string} word
   */
  add: function add(word) {
    var i, char, node = this._root, uword;
    if( !(typeof word === 'string' || word instanceof String) ) {
      throw new TypeError("word is not string");
    }
    uword = word.toUpperCase();
    // Assert start position with a space character
    node = node[" "] || (node[" "] = {_parent: node});
    for( i = 0 ; i < uword.length; i++ ) {
      char = uword.charAt(i);
      node = node[char] || (node[char] = {_parent: node});
    }
    node._result = word;
  },
  compile: function compile() {
    var queue = [], entry, node, child, fall;

    queue.push(this._root);
    while( queue.length > 0 ) {
      node = queue.shift();
      delete node._fall;
      var keys = Object.keys(node);
      for( var i = 0 ; i < keys.length; i++ ) {
        var key = keys[i];
        if(key.length > 1) {
          continue;
        }
        queue.push(node[key]);
      }
    }

    this._root._fall = this._root;
    queue.push({char: null, node: this._root});
    while( queue.length > 0 ) {
      entry = queue.shift();
      node = entry.node;
      var keys = Object.keys(node);
      for( var i = 0 ; i < keys.length; i++ ) {
        var key = keys[i];
        if(key.length > 1) {
          continue;
        }
        var char = key;
        child = node[key];
        queue.push({char: char, node: child});
      }
      if( node === this._root ) {
        continue;
      }
      fall = node._parent._fall;
      while( fall[entry.char] === undefined && fall !== this._root ) {
        fall = fall._fall;
      }
      node._fall = fall[entry.char] || this._root;
      if( node._fall === node ) {
        node._fall = this._root;
      }
    }
  },
  search: function search(text) {
    var result = [], state = this._root, node, i, self=this;
    if( !(typeof text === 'string' || text instanceof String) ) {
      throw new TypeError("word is not string");
    }
    text = text.toUpperCase();
    var step = function search_step(char) {
      node = state;
      while( node[char] === undefined && node !== self._root ) {
        node = node._fall;
      }
      if( node === self._root ) {
        node = node[char] || self._root;
      }
      else {
        node = node[char];
      }
      state = node;
      while( node !== self._root ) {
        if( node._result ) {
          result.push(node._result);
        }
        node = node._fall;
      }
    };
    step(" ");
    for( i = 0 ; i < text.length ; i++ ) {
      step(text.charAt(i));
    }
    return result;
  }
};

var getCharIDs = function getCharIDs(characterList, next) {
  https.get('https://api.eveonline.com/Eve/CharacterID.xml.aspx?names=' + characterList.join(","), function(response){
    var result = '';
    response.on('data', function(chunk){result += chunk;});
    response.on('end', function() {
      var xml = etree.parse(result);
      xml.findall('./result/rowset/row').map(function(row) {
        if( characters[row.attrib.name.toUpperCase()] !== undefined ) {
          return;
        }
        var charID = parseInt(row.attrib.characterID);
        if( charID !== 0 ){
          characters[row.attrib.name.toUpperCase()] = charID;
          charDict.add(row.attrib.name);
        }
        else {
          characters[row.attrib.name.toUpperCase()] = null;
        }
      });
      charDict.compile();
      next();
    });
  });
};

var system_list;
request({url: Data.config.domain + '/data/map.json', json: true}, function (error, response, body) {
  if (error) console.log(error);
  system_list = body.Systems;
});

var lineRegex = /\[ (\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2}) \] ([\w ]+) > (.*)/i;
var killmailRegex = /Kill: (.*) \((.*)\)/i;
var characters = Object.create(null);
var charDict = new Dict();

var processLine = function processLine(line, next) {
  if(line != undefined) {

    // Strip control characters
    var buffer = encoding.convert(line, 'utf-16');
    var result = lineRegex.exec(buffer.slice(7).toString().replace(/\0/g,''));

    if(result) {
      var timestamp = result[1];
      var sender = result[2];
      var text = result[3];
      var requestList = [];
      var resolvedCharacters = {};
      var clear = false;

      if( sender === 'EVE System') {
        next();
        return;
      }

      if(characters[sender.toUpperCase()] === undefined) {
        requestList.push(sender);
      }

      var killmailResult = killmailRegex.exec(line);
      if(killmailResult) {
        var deadCharacter = killmailResult[1];
        var lostShip = killmailResult[2];
        requestList.push(deadCharacter);

        var getCharIDsComplete = function getCharIDsComplete() {
          next({time: Util.getTime(), raw: line, type: 'sourcedKillmail',
                data: { type: 'sourcedKillmail', reporterId: characters[sender.toUpperCase()], reporterName: sender,
                pilots: {deadCharacter: characters[deadCharacter.toUpperCase()]}, lostShip: lostShip}});
        };
        if(requestList.length > 0) {
          getCharIDs(requestList, getCharIDsComplete);
        }
        else {
          getCharIDsComplete();
        }
      }
      else {
        var split = text.split("  ");
        var system;

        split.forEach(function (element) {
          var matched_system = _.findLast(system_list, function(s) {
            var r = new RegExp('^' + s.name + '[a-z0-9\\-]{0,3}$', 'i');
            return r.test(element);
          });

          if(matched_system !== undefined) {
            system = {systemName: matched_system.name, systemId: matched_system.id, regionId: matched_system.regionID};
            if (element.toUpperCase() === system.systemName.toUpperCase()) return;
          }

          if(characters[element.toUpperCase()] === undefined) {
            var searchResult = charDict.search(element).sort(function(a,b){return b.length - a.length}).shift();
            if( searchResult !== undefined && characters[searchResult.toUpperCase()] !== null ) {
              resolvedCharacters[searchResult] = characters[searchResult.toUpperCase()];
            }
            else if( /(clear|clr|empty)/.test(element) ) {
              clear = true;
            }
            else if( /^[A-Za-z0-9\-\_\' ]+$/.test(element) ) {
              requestList.push(element);
            }
          }
          else if( characters[element.toUpperCase()] !== null ) {
            resolvedCharacters[element] = characters[element.toUpperCase()];
          }
        });

        if( system ) {
          var type = (clear) ? 'sourcedClear' : 'sourcedHostile';
          if( requestList.length > 0 ) {
            var getCharIDsComplete = function getCharIDsComplete() {
              // if (!Object.keys(resolvedCharacters).length) return next();

              requestList.filter(function(c){return c !== sender && characters[c.toUpperCase()] != null;})
                .forEach(function(c){resolvedCharacters[c] = characters[c.toUpperCase()]});

              return next({time: Util.getTime(), type: type, raw: line, data: {clear: clear, type: type,
                reporterId: characters[sender.toUpperCase()], reporterName: sender,
                systemName: system.systemName, systemId: system.systemId,
                pilots: resolvedCharacters}});
            };
            getCharIDs(requestList, getCharIDsComplete);
          }
          else {
            return next({time: Util.getTime(), type: type, raw: line, data: {clear: clear, type: type,
                  reporterId: characters[sender.toUpperCase()], reporterName: sender,
                  systemName: system.systemName, systemId: system.systemId,
                  pilots: resolvedCharacters}});
          }
        }
        else {
          return next();
        }
      }
    }
    else {
      return next();
    }
  }
};

var path = require('path');
var UIPanels = {

  substringMatcher: function(strs) {
    return function findMatches(q, cb) {
      var matches, substrRegex;
      matches = [];
      substrRegex = new RegExp(q, 'i');

      $.each(strs, function(i, str) {
        if (substrRegex.test(str)) matches.push({ value: str });
      });

      cb(matches);
    };
  },

  showMenuPanel: function(callback) {
    var panel = {
      type: 'options',
      icon: 'settings',
      title: 'Standing Fleet Options',
      footer: '&copy; 2015 Goonswarm Federation',
      closeable: true,
      formitems: [
        {checkbox: {label: 'Clipboard Polling', checked: Data.state.poll.clipboard, onclick: 'UI.togglePolling(this, "clipboard");' }},
        {checkbox: {label: 'Log Polling', checked: Data.state.poll.logs, onclick: 'UI.togglePolling(this, "logs");' }}
      ]
    };

    if (/^win/.test(process.platform)) {
      panel.formitems.push({input: {legend: 'Log Path', label: 'Log Path', class: 'log-path', onblur: 'UI.updateLogPath(this);', value: Data.state.datasources.logs.path.win}});
    } else {
      panel.formitems.push({input: {legend: 'Log Path', label: 'Log Path', class: 'log-path', onblur: 'UI.updateLogPath(this);', value: Data.state.datasources.logs.path.darwin}});
    }

    var channels = {group: {legend: 'Intel Channels', formitems: []}};
    for (var channel in Data.state.datasources.logs.channels) {
      channels.group.formitems.push(
        {checkbox: {label: channel, checked: Data.state.datasources.logs.channels[channel], onclick: 'UI.toggleChannel(this, "' + channel + '");' }}
      );
    }
    panel.formitems.push(channels);

    UIPanels.showPanel(panel, callback);
  },

  showPendingPanel: function (callback) {
    var panel = {
      type: 'pending',
      image: 'spinner.gif',
      text: 'Waiting for Standing Fleet to accept...',
      formitems: [
        {button: {text: 'Cancel', class: 'abort-pending', onClick: 'leaveFleetButtonClick(this)'}}
      ],
    };

    UIPanels.showPanel(panel, callback);
  },

  showLoadingPanel: function (text, callback) {
    var panel = {
      type: 'loading',
      title: text || UI.getLoadingText(),
      image: 'spinner.gif'
    };

    UIPanels.showPanel(panel, callback);
  },

  showPanel: function (params, callback) {
    var compiledPanel = $(Data.templates.panel(params));

    if (Data.ui.dim.children().length) {

      Data.ui.dim.children().remove();
      compiledPanel
        .css('display','none')
        .appendTo(Data.ui.dim)
        .fadeIn(Data.config.uiSpeed, function () {
          $(this).find('.textinput').focus().on('keydown', function (event) {
            if (event.keyCode == 13) {
              $(this).siblings('.submit-join, .submit-scan').click();
              return false;
            }
          });
          if (callback) callback();
        });

    } else {

      compiledPanel.appendTo(Data.ui.dim);
      UI.dim(function () {
        compiledPanel.find('.textinput').focus().on('keydown', function (event) {
          if (event.keyCode == 13) {
            $(this).siblings('.submit-join, .submit-scan').click();
            return false;
          }
        });
        if (callback) callback();
      });
    }
  },

  hidePanel: function (callback) {
    Data.ui.dim.children().remove();
    UI.unDim(callback);
  }

};

var UI = {

  dim: function(callback) {
    if (!Data.state.dimmed) {
      Data.ui.dim.fadeIn(Data.config.uiSpeed, callback);
    }
  },

  unDim: function(callback) {
    if (!Data.state.dimmed) {
      Data.ui.dim.fadeOut(Data.config.uiSpeed, callback);
    }

    return UI;
  },

  startSpin: function () {
    Data.ui.bottomMenu_spinner
      .fadeIn(Data.config.uiSpeed*4);
  },

  stopSpin: function () {
    Data.ui.bottomMenu_spinner
      .fadeOut(Data.config.uiSpeed*4);
  },

  togglePolling: function (checkbox, source) {
    if (source == 'clipboard') Data.state.poll.clipboard = checkbox.checked;
    if (source == 'logs') {
      Data.state.poll.logs = checkbox.checked;
      resetLogPolling();
    }
  },

  toggleChannel: function(checkbox, channel) {
    Data.state.datasources.logs.channels[ channel ] = checkbox.checked;
  },

  updateLogPath: function(input) {
    if (/^win/.test(process.platform)) {
      Data.state.datasources.logs.path.win = input.value;
    } else {
      Data.state.datasources.logs.path.osx = input.value;
    }
  },

  registerEventHandlers: function () {
    Data.ui.topMenu_clipboard.on('click', $.proxy(UI.tabClick, null, 'clipboard'));
    Data.ui.topMenu_logs.on('click', $.proxy(UI.tabClick, null, 'logs'));
    Data.ui.bottomMenu_menu.on('click', $.proxy(UIPanels.showMenuPanel, null, false));
    UI.update_scrollables();
  },

  update_scrollables: function() {
    Data.ui.clipboard_list.slimScroll({height: 'auto', color: '#ffcc2a', alwaysVisible: true});
    Data.ui.logs_list.slimScroll({height: 'auto', color: '#ffcc2a', alwaysVisible: true});
  },

  showAlert: function (event) {
    var alert = $(Data.templates.alert(event));

    alert.on('mouseover',function () {
      alert.stop(true, true);
    }).on('mouseout',function () {
      UI.idleAlert(alert);
    });

    Data.ui.alertContainer.append(alert);

    alert.fadeIn(Data.config.uiSpeed, function () {
      UI.idleAlert(alert);
    });
  },

  idleAlert: function (alert) {
    alert.delay(Data.config.alertStay)
      .fadeOut(Data.config.uiSpeed, function() {
        alert.remove();
      });
  },

  tabClick: function (tab) {
    if ($('#'+tab).hasClass('active')) return;

    $('#content-wrapper').fadeOut('fast',function(){
      $('.main-content.active, .menu-button.active ').removeClass('active');
      $('.menu-button.' + tab + ', #' + tab).addClass('active');
      $('.menu-button.' + tab).removeClass('blink');
      $('#content-wrapper').fadeIn('fast');
    });
  },

  blinkTab: function (tab) {
    if ($('#'+tab).hasClass('active')) return;
    $('.menu-button.' + tab).addClass('blink');
  },

  getLoadingText: function () {
    var msgs = [
      "Hull tanking",
      "EFT warrioring",
      "Smacktalking",
      "Shitpoasting",
      "Lemming'ing",
      "Clicking jump instead of bridge",
      "Overheating guns",
      "Bumping the titan",
      "Fitting a windicator",
      "Burning point",
      "Posting gudfites",
      "Z0r",
      "Whoring on the pod"
    ];
    return msgs[Math.floor(Math.random()*msgs.length)] + "...";
  }
}

Handlebars.registerHelper('ui_icon', function(icon) {
  if (icon == 'alert') return 'bell';
  if (icon == 'approve') return 'check';
  if (icon == 'close') return 'close';
  if (icon == 'deny') return 'thumbs-down';
  if (icon == 'dscan') return 'wifi';
  if (icon == 'error') return 'exclamation-triangle';
  if (icon == 'fleet') return 'fighter-jet';
  if (icon == 'fleetCreated') return 'fighter-jet';
  if (icon == 'hostileTimeout') return 'clock-o';
  if (icon == 'info') return 'question';
  if (icon == 'member') return 'user';
  if (icon == 'memberJoined') return 'user';
  if (icon == 'memberLeft') return 'user';
  if (icon == 'memberTimedOut') return 'clock-o';
  if (icon == 'options') return 'cog';
  if (icon == 'reportClear') return 'check';
  if (icon == 'reportHostile') return 'crosshairs';
  if (icon == 'scan') return 'wifi';
  if (icon == 'scanPosted') return 'wifi';
  if (icon == 'settings') return 'cog';
  if (icon == 'shipLost') return 'bolt';
  if (icon == 'sourcedClear') return 'check';
  if (icon == 'sourcedClipboard') return 'clipboard';
  if (icon == 'sourcedHostile') return 'crosshairs';
  if (icon == 'updateHostile') return 'crosshairs';
  if (icon == 'updateSystemMap') return 'sitemap';
  if (icon == 'youJoined') return 'user';

  return 'exclamation';
});

Handlebars.registerHelper('reported', function(pilots) {
  if (Object.keys(pilots).length > 1) {
    return Object.keys(pilots).length + ' hostiles ';
  } else {
    return Object.keys(pilots)[0];
  }
});

Handlebars.registerHelper("debug", function(optionalValue) {
  console.log("Current Context");
  console.log("====================");
  console.log(this);
 
  if (optionalValue) {
    console.log("Value");
    console.log("====================");
    console.log(optionalValue);
  }
});

var moment = require('moment')

var Util = {
  getTime: function () {
    return moment().utc().format('HH:mm:ss');
  }
};

function log(message) {
  console.log('[' + moment().unix() + '] - ' + message);
}
