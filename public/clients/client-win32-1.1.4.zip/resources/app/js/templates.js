this["Templates"] = this["Templates"] || {};
this["Templates"]["alert"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<div class=\"event alert "
    + alias3(((helper = (helper = helpers.type || (depth0 != null ? depth0.type : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"type","hash":{},"data":data}) : helper)))
    + "\" onClick=\"EventList.alertClick('"
    + alias3(((helper = (helper = helpers.type || (depth0 != null ? depth0.type : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"type","hash":{},"data":data}) : helper)))
    + "', '"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "')\">\r\n  <span class=\"text\"><i class=\"fa fa-"
    + alias3((helpers.ui_icon || (depth0 && depth0.ui_icon) || alias1).call(depth0,(depth0 != null ? depth0.type : depth0),{"name":"ui_icon","hash":{},"data":data}))
    + "\"></i> "
    + ((stack1 = ((helper = (helper = helpers.text || (depth0 != null ? depth0.text : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"text","hash":{},"data":data}) : helper))) != null ? stack1 : "")
    + "</span>\r\n</div>\r\n";
},"useData":true});
this["Templates"]["event"] = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<div class=\"event "
    + alias3(((helper = (helper = helpers.type || (depth0 != null ? depth0.type : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"type","hash":{},"data":data}) : helper)))
    + "\" data-key=\""
    + alias3(((helper = (helper = helpers.key || (depth0 != null ? depth0.key : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"key","hash":{},"data":data}) : helper)))
    + "\">\r\n  <i class=\"fa fa-"
    + alias3((helpers.ui_icon || (depth0 && depth0.ui_icon) || alias1).call(depth0,(depth0 != null ? depth0.type : depth0),{"name":"ui_icon","hash":{},"data":data}))
    + "\"></i>\r\n  <span class=\"text\">"
    + ((stack1 = ((helper = (helper = helpers.text || (depth0 != null ? depth0.text : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"text","hash":{},"data":data}) : helper))) != null ? stack1 : "")
    + "</span>\r\n  <div class=\"right\">\r\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.respondable : depth0),{"name":"if","hash":{},"fn":this.program(2, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    <span class=\"time\">"
    + alias3(((helper = (helper = helpers.time || (depth0 != null ? depth0.time : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"time","hash":{},"data":data}) : helper)))
    + "</span>\r\n  </div>\r\n</div>\r\n";
},"2":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "    <span class=\"response\">\r\n      <a href=\"javascript:EventList.eventResponseClick('"
    + alias3(((helper = (helper = helpers.key || (depth0 != null ? depth0.key : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"key","hash":{},"data":data}) : helper)))
    + "', 'y')\">Approve</a>\r\n      &nbsp;|&nbsp;\r\n      <a href=\"javascript:EventList.eventResponseClick('"
    + alias3(((helper = (helper = helpers.key || (depth0 != null ? depth0.key : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"key","hash":{},"data":data}) : helper)))
    + "', 'n')\">Deny</a>\r\n    </span>\r\n";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1;

  return ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.text : depth0),{"name":"if","hash":{},"fn":this.program(1, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "");
},"useData":true});
this["Templates"]["hostile"] = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    return "faded";
},"3":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "      <a href=\"javascript:CCPEVE.showInfo(16159, "
    + alias3(((helper = (helper = helpers.allianceId || (depth0 != null ? depth0.allianceId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"allianceId","hash":{},"data":data}) : helper)))
    + ");\">&lt;"
    + alias3(((helper = (helper = helpers.allianceName || (depth0 != null ? depth0.allianceName : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"allianceName","hash":{},"data":data}) : helper)))
    + "&gt;</a>\r\n";
},"5":function(depth0,helpers,partials,data) {
    return "      No Alliance\r\n";
},"7":function(depth0,helpers,partials,data) {
    return "    <i class=\"fa fa-university\"></i> Docked\r\n";
},"9":function(depth0,helpers,partials,data) {
    var stack1;

  return ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.shipTypeId : depth0),{"name":"if","hash":{},"fn":this.program(10, data, 0),"inverse":this.program(12, data, 0),"data":data})) != null ? stack1 : "");
},"10":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "        <i class=\"fa fa-fighter-jet\"></i> <a href=\"javascript:CCPEVE.showInfo("
    + alias3(((helper = (helper = helpers.shipTypeId || (depth0 != null ? depth0.shipTypeId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"shipTypeId","hash":{},"data":data}) : helper)))
    + ");\">"
    + alias3(((helper = (helper = helpers.shipType || (depth0 != null ? depth0.shipType : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"shipType","hash":{},"data":data}) : helper)))
    + "</a>\r\n";
},"12":function(depth0,helpers,partials,data) {
    return "        Non Visual\r\n";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<tr id=\"hostile-"
    + alias3(((helper = (helper = helpers.characterId || (depth0 != null ? depth0.characterId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"characterId","hash":{},"data":data}) : helper)))
    + "\" class=\"hostile "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.is_faded : depth0),{"name":"if","hash":{},"fn":this.program(1, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\">\r\n  <td class=\"ship-icon\">"
    + ((stack1 = ((helper = (helper = helpers.shipIcon || (depth0 != null ? depth0.shipIcon : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"shipIcon","hash":{},"data":data}) : helper))) != null ? stack1 : "")
    + "</td>\r\n  <td class=\"name\"><a href=\"javascript:CCPEVE.showInfo(1377, "
    + alias3(((helper = (helper = helpers.characterId || (depth0 != null ? depth0.characterId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"characterId","hash":{},"data":data}) : helper)))
    + ");\">"
    + alias3(((helper = (helper = helpers.characterName || (depth0 != null ? depth0.characterName : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"characterName","hash":{},"data":data}) : helper)))
    + "</a></td>\r\n  <td class=\"alliance\">\r\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.allianceName : depth0),{"name":"if","hash":{},"fn":this.program(3, data, 0),"inverse":this.program(5, data, 0),"data":data})) != null ? stack1 : "")
    + "  </td>\r\n  <td class=\"ship-type\" onClick=\"UIPanels.updateHostileDetailsPanel('"
    + alias3(((helper = (helper = helpers.characterId || (depth0 != null ? depth0.characterId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"characterId","hash":{},"data":data}) : helper)))
    + "');\">\r\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.is_docked : depth0),{"name":"if","hash":{},"fn":this.program(7, data, 0),"inverse":this.program(9, data, 0),"data":data})) != null ? stack1 : "")
    + "  </td>\r\n  <td class=\"system\"><a href=\"javascript:CCPEVE.showInfo(5,"
    + alias3(((helper = (helper = helpers.systemId || (depth0 != null ? depth0.systemId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"systemId","hash":{},"data":data}) : helper)))
    + ");\">"
    + alias3(((helper = (helper = helpers.systemName || (depth0 != null ? depth0.systemName : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"systemName","hash":{},"data":data}) : helper)))
    + "</a></td>\r\n  <td class=\"reported-at\"><a title=\"Reported by "
    + alias3(((helper = (helper = helpers.reporterName || (depth0 != null ? depth0.reporterName : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"reporterName","hash":{},"data":data}) : helper)))
    + "\">"
    + alias3((helpers.format_ts_short || (depth0 && depth0.format_ts_short) || alias1).call(depth0,(depth0 != null ? depth0.ts : depth0),{"name":"format_ts_short","hash":{},"data":data}))
    + "</a></td>\r\n  <td class=\"actions\">\r\n    <a title=\"Set Destination\" onClick=\"CCPEVE.setDestination("
    + alias3(((helper = (helper = helpers.systemId || (depth0 != null ? depth0.systemId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"systemId","hash":{},"data":data}) : helper)))
    + ")\"><i class=\"fa fa-map-marker\" title=\"Set Destination\"></i></a>\r\n    <a title=\"Killboard: "
    + alias3(((helper = (helper = helpers.characterName || (depth0 != null ? depth0.characterName : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"characterName","hash":{},"data":data}) : helper)))
    + "\" target=\"_blank\" href=\"https://zkillboard.com/character/"
    + alias3(((helper = (helper = helpers.characterId || (depth0 != null ? depth0.characterId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"characterId","hash":{},"data":data}) : helper)))
    + "/\"><i class=\"fa fa-crosshairs\" title=\"Killboard\"></i></a>\r\n  </td>\r\n</tr>\r\n";
},"useData":true});
this["Templates"]["hud"] = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing;

  return "        <div><i class=\"fa fa-"
    + ((stack1 = (helpers.hud_neighbor_status || (depth0 && depth0.hud_neighbor_status) || alias1).call(depth0,(depth0 != null ? depth0.id : depth0),(depth0 != null ? depth0.name : depth0),{"name":"hud_neighbor_status","hash":{},"data":data})) != null ? stack1 : "")
    + "\"></i> "
    + this.escapeExpression(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias1),(typeof helper === "function" ? helper.call(depth0,{"name":"name","hash":{},"data":data}) : helper)))
    + "</div>\r\n";
},"3":function(depth0,helpers,partials,data) {
    return "        <div>No Connecting Systems</div>\r\n";
},"5":function(depth0,helpers,partials,data) {
    var stack1, helper;

  return "        <li>\r\n          "
    + this.escapeExpression(((helper = (helper = helpers.characterName || (depth0 != null ? depth0.characterName : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"characterName","hash":{},"data":data}) : helper)))
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.shipType : depth0),{"name":"if","hash":{},"fn":this.program(6, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n        </li>\r\n";
},"6":function(depth0,helpers,partials,data) {
    var helper;

  return ": <i class=\"fa fa-fighter-jet\"></i> "
    + this.escapeExpression(((helper = (helper = helpers.shipType || (depth0 != null ? depth0.shipType : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"shipType","hash":{},"data":data}) : helper)));
},"8":function(depth0,helpers,partials,data) {
    return "        <li>None reported</li>\r\n";
},"10":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2=this.escapeExpression;

  return "          <li><i class=\"fa fa-"
    + alias2((helpers.ui_icon || (depth0 && depth0.ui_icon) || alias1).call(depth0,(depth0 != null ? depth0.type : depth0),{"name":"ui_icon","hash":{},"data":data}))
    + "\"></i> "
    + alias2(((helper = (helper = helpers.type || (depth0 != null ? depth0.type : depth0)) != null ? helper : alias1),(typeof helper === "function" ? helper.call(depth0,{"name":"type","hash":{},"data":data}) : helper)))
    + "</li>\r\n";
},"12":function(depth0,helpers,partials,data) {
    return "          <li>None reported</li>\r\n";
},"14":function(depth0,helpers,partials,data) {
    var stack1;

  return ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.system : depth0)) != null ? stack1.name : stack1),{"name":"if","hash":{},"fn":this.program(15, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "");
},"15":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=this.escapeExpression;

  return "    <h3>"
    + alias1(this.lambda(((stack1 = (depth0 != null ? depth0.system : depth0)) != null ? stack1.name : stack1), depth0))
    + ": "
    + alias1(((helper = (helper = helpers.hostiles || (depth0 != null ? depth0.hostiles : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"hostiles","hash":{},"data":data}) : helper)))
    + " hostile"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.hostiles : depth0),{"name":"if","hash":{},"fn":this.program(16, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + " "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.faded : depth0),{"name":"if","hash":{},"fn":this.program(18, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "</h3>\r\n";
},"16":function(depth0,helpers,partials,data) {
    return "s";
},"18":function(depth0,helpers,partials,data) {
    var helper;

  return "("
    + this.escapeExpression(((helper = (helper = helpers.faded || (depth0 != null ? depth0.faded : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"faded","hash":{},"data":data}) : helper)))
    + " faded)";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing;

  return "<div class=\"screen "
    + this.escapeExpression(((helper = (helper = helpers.status || (depth0 != null ? depth0.status : depth0)) != null ? helper : alias1),(typeof helper === "function" ? helper.call(depth0,{"name":"status","hash":{},"data":data}) : helper)))
    + "\">\r\n  <div class=\"console\">\r\n    <h2>"
    + ((stack1 = (helpers.hud_status_text || (depth0 && depth0.hud_status_text) || alias1).call(depth0,(depth0 != null ? depth0.status : depth0),{"name":"hud_status_text","hash":{},"data":data})) != null ? stack1 : "")
    + "</h2>\r\n\r\n    <div class=\"vicinity\">\r\n      <h3>Vicinity</h3>\r\n      <div class=\"systems\">\r\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.vicinity : depth0),{"name":"each","hash":{},"fn":this.program(1, data, 0),"inverse":this.program(3, data, 0),"data":data})) != null ? stack1 : "")
    + "      </div>\r\n    </div>\r\n\r\n    <div class=\"hostiles\">\r\n      <h3>Hostiles</h3>\r\n      <ul>\r\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.hostiles : depth0),{"name":"each","hash":{},"fn":this.program(5, data, 0),"inverse":this.program(8, data, 0),"data":data})) != null ? stack1 : "")
    + "      </ul>\r\n    </div>\r\n\r\n    <div class=\"advisories\">\r\n      <h3>Advisories</h3>\r\n      <ul>\r\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.advisories : depth0),{"name":"each","hash":{},"fn":this.program(10, data, 0),"inverse":this.program(12, data, 0),"data":data})) != null ? stack1 : "")
    + "      </ul>\r\n    </div>\r\n\r\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.neighbors : depth0),{"name":"each","hash":{},"fn":this.program(14, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n  </div>\r\n</div>\r\n";
},"useData":true});
this["Templates"]["jumpbridge_link_info"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, alias1=this.lambda, alias2=this.escapeExpression;

  return "<div class=\"jumpbridge-link-details\">\r\n  <h3>"
    + alias2(alias1(((stack1 = ((stack1 = (depth0 != null ? depth0.source : depth0)) != null ? stack1.system : stack1)) != null ? stack1.name : stack1), depth0))
    + " <i class=\"fa fa-arrows-h\"></i> "
    + alias2(alias1(((stack1 = ((stack1 = (depth0 != null ? depth0.target : depth0)) != null ? stack1.system : stack1)) != null ? stack1.name : stack1), depth0))
    + "</h3>\r\n  \r\n  <h4>Locations</h4>\r\n  <dl>\r\n    <dt>"
    + alias2(alias1(((stack1 = ((stack1 = (depth0 != null ? depth0.source : depth0)) != null ? stack1.system : stack1)) != null ? stack1.name : stack1), depth0))
    + "</dt>\r\n    <dd>"
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.jumpbridge_data : depth0)) != null ? stack1.fromPlanet : stack1), depth0))
    + " - "
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.jumpbridge_data : depth0)) != null ? stack1.fromMoon : stack1), depth0))
    + "</dd>\r\n    \r\n    <dt>"
    + alias2(alias1(((stack1 = ((stack1 = (depth0 != null ? depth0.target : depth0)) != null ? stack1.system : stack1)) != null ? stack1.name : stack1), depth0))
    + "</dt>\r\n    <dd>"
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.jumpbridge_data : depth0)) != null ? stack1.toPlanet : stack1), depth0))
    + " - "
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.jumpbridge_data : depth0)) != null ? stack1.toMoon : stack1), depth0))
    + "</dd>\r\n  </dl>\r\n  \r\n  <h4>Details</h4>\r\n  <dl>\r\n    <dt>Owner</dt>\r\n    <dd>"
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.jumpbridge_data : depth0)) != null ? stack1.owner : stack1), depth0))
    + "</dd>\r\n\r\n    <dt>Password</dt>\r\n    <dd>"
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.jumpbridge_data : depth0)) != null ? stack1.password : stack1), depth0))
    + "</dd>\r\n\r\n    <dt>Designation</dt>\r\n    <dd>"
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.jumpbridge_data : depth0)) != null ? stack1.route : stack1), depth0))
    + "</dd>\r\n    \r\n    <dt>Distance</dt>\r\n    <dd>"
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.jumpbridge_data : depth0)) != null ? stack1.distance : stack1), depth0))
    + "ly</dd>\r\n\r\n    <dt>Friendly</dt>\r\n    <dd>"
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.jumpbridge_data : depth0)) != null ? stack1.friendly : stack1), depth0))
    + "</dd>\r\n  </dl>  \r\n</div>\r\n";
},"useData":true});
this["Templates"]["map_legend"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    return "<strong class=\"heading\">Map Legend</strong>\r\n<ul>\r\n  <li><span class=\"system-unknown current\">System</span>Current System</li>\r\n  <li><span class=\"system-unknown\">System</span>No Visual</li>\r\n  <li><span class=\"system-clear\">System</span>Clear</li>\r\n  <li><span class=\"system-warning\">System</span>Advisory Issued</li>\r\n  <li><span class=\"system-hostile\">System</span>Hostile</li>\r\n  <li><hr class=\"link\" /> System Gate\r\n  <li><hr class=\"link constellation\" /> Constellation Gate\r\n  <li><hr class=\"link region\" /> Regional Gate\r\n  <li><hr class=\"link wormhole\" /> Wormhole\r\n  <li><hr class=\"link jumpbridge\" /> Jumpbridge\r\n</ul>\r\n";
},"useData":true});
this["Templates"]["member"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<tr class=\"member\" id=\"member-"
    + alias3(((helper = (helper = helpers.characterId || (depth0 != null ? depth0.characterId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"characterId","hash":{},"data":data}) : helper)))
    + "\">\r\n  <td class=\"name\"><a href=\"javascript:CCPEVE.showInfo(1377, "
    + alias3(((helper = (helper = helpers.characterId || (depth0 != null ? depth0.characterId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"characterId","hash":{},"data":data}) : helper)))
    + ");\">"
    + alias3(((helper = (helper = helpers.characterName || (depth0 != null ? depth0.characterName : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"characterName","hash":{},"data":data}) : helper)))
    + "</a></td>\r\n  <td class=\"actions\">\r\n    <a title=\"Start Conversation\" onClick=\"CCPEVE.startConversation("
    + alias3(((helper = (helper = helpers.characterId || (depth0 != null ? depth0.characterId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"characterId","hash":{},"data":data}) : helper)))
    + ")\"><i class=\"fa fa-comment\" title=\"Start Conversation\"></i></a>\r\n    <a title=\"Killboard: "
    + alias3(((helper = (helper = helpers.characterName || (depth0 != null ? depth0.characterName : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"characterName","hash":{},"data":data}) : helper)))
    + "\" target=\"_blank\" href=\"https://zkillboard.com/character/"
    + alias3(((helper = (helper = helpers.characterId || (depth0 != null ? depth0.characterId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"characterId","hash":{},"data":data}) : helper)))
    + "/\"><i class=\"fa fa-crosshairs\" title=\"Killboard\"></i></a>\r\n  </td>\r\n</tr>\r\n";
},"useData":true});
this["Templates"]["panel"] = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    return "<i class=\"close fa fa-times fa-2x\" onClick=\"UIPanels.hidePanel()\"></i>";
},"3":function(depth0,helpers,partials,data) {
    return "<i class=\"fa fa-"
    + this.escapeExpression((helpers.ui_icon || (depth0 && depth0.ui_icon) || helpers.helperMissing).call(depth0,(depth0 != null ? depth0.icon : depth0),{"name":"ui_icon","hash":{},"data":data}))
    + " fa-3x\"></i>";
},"5":function(depth0,helpers,partials,data) {
    var helper;

  return "<img src=\"/images/"
    + this.escapeExpression(((helper = (helper = helpers.image || (depth0 != null ? depth0.image : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"image","hash":{},"data":data}) : helper)))
    + "\" alt=\"Panel image\" />";
},"7":function(depth0,helpers,partials,data) {
    return "<img id=\"logo\" src=\"/images/panel-logo.png\" alt=\"Standing Fleet\" />";
},"9":function(depth0,helpers,partials,data) {
    var stack1, helper;

  return "<div class=\"text title\">"
    + ((stack1 = ((helper = (helper = helpers.title || (depth0 != null ? depth0.title : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"title","hash":{},"data":data}) : helper))) != null ? stack1 : "")
    + "</div>";
},"11":function(depth0,helpers,partials,data) {
    var stack1, helper;

  return "    <div class=\"text "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.textclass : depth0),{"name":"if","hash":{},"fn":this.program(12, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\">"
    + ((stack1 = ((helper = (helper = helpers.text || (depth0 != null ? depth0.text : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"text","hash":{},"data":data}) : helper))) != null ? stack1 : "")
    + "</div>\r\n";
},"12":function(depth0,helpers,partials,data) {
    var helper;

  return this.escapeExpression(((helper = (helper = helpers.textclass || (depth0 != null ? depth0.textclass : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"textclass","hash":{},"data":data}) : helper)));
},"14":function(depth0,helpers,partials,data) {
    var stack1;

  return "    <span class=\"error\">"
    + ((stack1 = this.lambda(((stack1 = (depth0 != null ? depth0.error : depth0)) != null ? stack1.message : stack1), depth0)) != null ? stack1 : "")
    + "</span>\r\n";
},"16":function(depth0,helpers,partials,data) {
    var stack1;

  return "    <div class=\"form\">\r\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.formitems : depth0),{"name":"each","hash":{},"fn":this.program(17, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    </div>\r\n";
},"17":function(depth0,helpers,partials,data) {
    var stack1;

  return ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.input : depth0),{"name":"if","hash":{},"fn":this.program(18, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.password : depth0),{"name":"if","hash":{},"fn":this.program(37, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.textinput : depth0),{"name":"if","hash":{},"fn":this.program(40, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.button : depth0),{"name":"if","hash":{},"fn":this.program(45, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.checkbox : depth0),{"name":"if","hash":{},"fn":this.program(48, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.submit : depth0),{"name":"if","hash":{},"fn":this.program(53, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.group : depth0),{"name":"if","hash":{},"fn":this.program(56, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "");
},"18":function(depth0,helpers,partials,data) {
    var stack1;

  return "      <div class=\"group\">\r\n        "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.input : depth0)) != null ? stack1.legend : stack1),{"name":"if","hash":{},"fn":this.program(19, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n        <input "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.input : depth0)) != null ? stack1.id : stack1),{"name":"if","hash":{},"fn":this.program(21, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + " "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.input : depth0)) != null ? stack1.max : stack1),{"name":"if","hash":{},"fn":this.program(23, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.input : depth0)) != null ? stack1['class'] : stack1),{"name":"if","hash":{},"fn":this.program(25, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "value=\""
    + ((stack1 = this.lambda(((stack1 = (depth0 != null ? depth0.input : depth0)) != null ? stack1.value : stack1), depth0)) != null ? stack1 : "")
    + "\" type="
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.input : depth0)) != null ? stack1.hidden : stack1),{"name":"if","hash":{},"fn":this.program(27, data, 0),"inverse":this.program(29, data, 0),"data":data})) != null ? stack1 : "")
    + " "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.input : depth0)) != null ? stack1.readonly : stack1),{"name":"if","hash":{},"fn":this.program(31, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + " "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.input : depth0)) != null ? stack1.onblur : stack1),{"name":"if","hash":{},"fn":this.program(33, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + " "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.input : depth0)) != null ? stack1.label : stack1),{"name":"if","hash":{},"fn":this.program(35, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "/>\r\n      </div>\r\n";
},"19":function(depth0,helpers,partials,data) {
    var stack1;

  return "<span class=\"legend\">"
    + ((stack1 = this.lambda(((stack1 = (depth0 != null ? depth0.input : depth0)) != null ? stack1.legend : stack1), depth0)) != null ? stack1 : "")
    + "</span>";
},"21":function(depth0,helpers,partials,data) {
    var stack1;

  return "id=\""
    + this.escapeExpression(this.lambda(((stack1 = (depth0 != null ? depth0.input : depth0)) != null ? stack1.id : stack1), depth0))
    + "\" ";
},"23":function(depth0,helpers,partials,data) {
    var stack1;

  return "max=\""
    + this.escapeExpression(this.lambda(((stack1 = (depth0 != null ? depth0.input : depth0)) != null ? stack1.max : stack1), depth0))
    + "\" ";
},"25":function(depth0,helpers,partials,data) {
    var stack1;

  return "class=\""
    + this.escapeExpression(this.lambda(((stack1 = (depth0 != null ? depth0.input : depth0)) != null ? stack1['class'] : stack1), depth0))
    + "\" ";
},"27":function(depth0,helpers,partials,data) {
    return "\"hidden\"";
},"29":function(depth0,helpers,partials,data) {
    return "\"text\"";
},"31":function(depth0,helpers,partials,data) {
    return "readonly=\"true\"";
},"33":function(depth0,helpers,partials,data) {
    var stack1;

  return "onblur=\""
    + this.escapeExpression(this.lambda(((stack1 = (depth0 != null ? depth0.input : depth0)) != null ? stack1.onblur : stack1), depth0))
    + "\"";
},"35":function(depth0,helpers,partials,data) {
    var stack1;

  return "placeholder=\""
    + ((stack1 = this.lambda(((stack1 = (depth0 != null ? depth0.input : depth0)) != null ? stack1.label : stack1), depth0)) != null ? stack1 : "")
    + "\"";
},"37":function(depth0,helpers,partials,data) {
    var stack1, alias1=this.lambda;

  return "      <div class=\"group\">\r\n        "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.password : depth0)) != null ? stack1.legend : stack1),{"name":"if","hash":{},"fn":this.program(38, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n        <input id=\""
    + this.escapeExpression(alias1(((stack1 = (depth0 != null ? depth0.password : depth0)) != null ? stack1.id : stack1), depth0))
    + "\" value=\""
    + ((stack1 = alias1(((stack1 = (depth0 != null ? depth0.password : depth0)) != null ? stack1.value : stack1), depth0)) != null ? stack1 : "")
    + "\" type=\"password\" />\r\n      </div>\r\n";
},"38":function(depth0,helpers,partials,data) {
    var stack1;

  return "<span class=\"legend\">"
    + ((stack1 = this.lambda(((stack1 = (depth0 != null ? depth0.password : depth0)) != null ? stack1.legend : stack1), depth0)) != null ? stack1 : "")
    + "</span>";
},"40":function(depth0,helpers,partials,data) {
    var stack1, alias1=this.lambda;

  return "        "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.textinput : depth0)) != null ? stack1.legend : stack1),{"name":"if","hash":{},"fn":this.program(41, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n        <textarea id=\""
    + this.escapeExpression(alias1(((stack1 = (depth0 != null ? depth0.textinput : depth0)) != null ? stack1.id : stack1), depth0))
    + "\" class=\"textinput "
    + ((stack1 = alias1(((stack1 = (depth0 != null ? depth0.textinput : depth0)) != null ? stack1['class'] : stack1), depth0)) != null ? stack1 : "")
    + "\" "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.textinput : depth0)) != null ? stack1.label : stack1),{"name":"if","hash":{},"fn":this.program(43, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "></textarea>\r\n";
},"41":function(depth0,helpers,partials,data) {
    var stack1;

  return "<span class=\"legend\">"
    + ((stack1 = this.lambda(((stack1 = (depth0 != null ? depth0.textinput : depth0)) != null ? stack1.legend : stack1), depth0)) != null ? stack1 : "")
    + "</span>";
},"43":function(depth0,helpers,partials,data) {
    var stack1;

  return "placeholder=\""
    + this.escapeExpression(this.lambda(((stack1 = (depth0 != null ? depth0.textinput : depth0)) != null ? stack1.label : stack1), depth0))
    + "\"";
},"45":function(depth0,helpers,partials,data) {
    var stack1, alias1=this.lambda;

  return "      <div class=\"group\">\r\n        <a "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.button : depth0)) != null ? stack1.link : stack1),{"name":"if","hash":{},"fn":this.program(46, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + " target=\"_blank\" class=\"button "
    + ((stack1 = alias1(((stack1 = (depth0 != null ? depth0.button : depth0)) != null ? stack1['class'] : stack1), depth0)) != null ? stack1 : "")
    + "\" onClick=\""
    + ((stack1 = alias1(((stack1 = (depth0 != null ? depth0.button : depth0)) != null ? stack1.onClick : stack1), depth0)) != null ? stack1 : "")
    + "\">"
    + ((stack1 = alias1(((stack1 = (depth0 != null ? depth0.button : depth0)) != null ? stack1.text : stack1), depth0)) != null ? stack1 : "")
    + "</a>\r\n      </div>\r\n";
},"46":function(depth0,helpers,partials,data) {
    var stack1;

  return "href=\""
    + ((stack1 = this.lambda(((stack1 = (depth0 != null ? depth0.button : depth0)) != null ? stack1.link : stack1), depth0)) != null ? stack1 : "")
    + "\"";
},"48":function(depth0,helpers,partials,data) {
    var stack1, alias1=this.lambda;

  return "      <div class=\"group\">\r\n        <input type=\"checkbox\" id=\""
    + this.escapeExpression(alias1(((stack1 = (depth0 != null ? depth0.checkbox : depth0)) != null ? stack1.id : stack1), depth0))
    + "\" "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.checkbox : depth0)) != null ? stack1.checked : stack1),{"name":"if","hash":{},"fn":this.program(49, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + " "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.checkbox : depth0)) != null ? stack1.onclick : stack1),{"name":"if","hash":{},"fn":this.program(51, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + ">\r\n        <span class=\"label\">"
    + ((stack1 = alias1(((stack1 = (depth0 != null ? depth0.checkbox : depth0)) != null ? stack1.label : stack1), depth0)) != null ? stack1 : "")
    + "</span>\r\n      </div>\r\n";
},"49":function(depth0,helpers,partials,data) {
    return "checked";
},"51":function(depth0,helpers,partials,data) {
    var stack1;

  return "onclick=\""
    + this.escapeExpression(this.lambda(((stack1 = (depth0 != null ? depth0.checkbox : depth0)) != null ? stack1.onclick : stack1), depth0))
    + "\"";
},"53":function(depth0,helpers,partials,data) {
    var stack1, alias1=this.lambda;

  return "      <div class=\"submit\">\r\n        <a "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.submit : depth0)) != null ? stack1.link : stack1),{"name":"if","hash":{},"fn":this.program(54, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + " target=\"_blank\" class=\"button\" onClick=\""
    + ((stack1 = alias1(((stack1 = (depth0 != null ? depth0.submit : depth0)) != null ? stack1.onClick : stack1), depth0)) != null ? stack1 : "")
    + "\">"
    + ((stack1 = alias1(((stack1 = (depth0 != null ? depth0.submit : depth0)) != null ? stack1.text : stack1), depth0)) != null ? stack1 : "")
    + "</a>\r\n      </div>\r\n";
},"54":function(depth0,helpers,partials,data) {
    var stack1;

  return "href=\""
    + ((stack1 = this.lambda(((stack1 = (depth0 != null ? depth0.submit : depth0)) != null ? stack1.link : stack1), depth0)) != null ? stack1 : "")
    + "\"";
},"56":function(depth0,helpers,partials,data) {
    var stack1;

  return "        <div class=\"group\">\r\n          "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.group : depth0)) != null ? stack1.legend : stack1),{"name":"if","hash":{},"fn":this.program(57, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n          <div class=\"group-items\">\r\n"
    + ((stack1 = helpers.each.call(depth0,((stack1 = (depth0 != null ? depth0.group : depth0)) != null ? stack1.formitems : stack1),{"name":"each","hash":{},"fn":this.program(59, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "          </div>\r\n        </div>\r\n";
},"57":function(depth0,helpers,partials,data) {
    var stack1;

  return "<span class=\"legend\">"
    + this.escapeExpression(this.lambda(((stack1 = (depth0 != null ? depth0.group : depth0)) != null ? stack1.legend : stack1), depth0))
    + "</span>";
},"59":function(depth0,helpers,partials,data) {
    var stack1;

  return ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.checkbox : depth0),{"name":"if","hash":{},"fn":this.program(60, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "");
},"60":function(depth0,helpers,partials,data) {
    var stack1, alias1=this.lambda;

  return "              <div class=\"item\">\r\n                <input type=\"checkbox\" id=\""
    + this.escapeExpression(alias1(((stack1 = (depth0 != null ? depth0.checkbox : depth0)) != null ? stack1.id : stack1), depth0))
    + "\" "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.checkbox : depth0)) != null ? stack1.checked : stack1),{"name":"if","hash":{},"fn":this.program(49, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + " "
    + ((stack1 = helpers['if'].call(depth0,((stack1 = (depth0 != null ? depth0.checkbox : depth0)) != null ? stack1.onclick : stack1),{"name":"if","hash":{},"fn":this.program(51, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + ">\r\n                <span class=\"label\">"
    + ((stack1 = alias1(((stack1 = (depth0 != null ? depth0.checkbox : depth0)) != null ? stack1.label : stack1), depth0)) != null ? stack1 : "")
    + "</span>\r\n              </div>\r\n";
},"62":function(depth0,helpers,partials,data) {
    var stack1, helper;

  return "    <div class=\"text footer\">"
    + ((stack1 = ((helper = (helper = helpers.footer || (depth0 != null ? depth0.footer : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"footer","hash":{},"data":data}) : helper))) != null ? stack1 : "")
    + "</div>\r\n";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, helper;

  return "<div class=\"panel "
    + this.escapeExpression(((helper = (helper = helpers.type || (depth0 != null ? depth0.type : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"type","hash":{},"data":data}) : helper)))
    + "\">\r\n  <div class=\"header\">\r\n    "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.closeable : depth0),{"name":"if","hash":{},"fn":this.program(1, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n    "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.icon : depth0),{"name":"if","hash":{},"fn":this.program(3, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n    "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.image : depth0),{"name":"if","hash":{},"fn":this.program(5, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n    "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.logo : depth0),{"name":"if","hash":{},"fn":this.program(7, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n    "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.title : depth0),{"name":"if","hash":{},"fn":this.program(9, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n  </div>\r\n  <div class=\"content\">\r\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.text : depth0),{"name":"if","hash":{},"fn":this.program(11, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.error : depth0),{"name":"if","hash":{},"fn":this.program(14, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.formitems : depth0),{"name":"if","hash":{},"fn":this.program(16, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.footer : depth0),{"name":"if","hash":{},"fn":this.program(62, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "  </div>\r\n</div>\r\n";
},"useData":true});
this["Templates"]["report"] = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "  <i class=\"fa fa-check\"></i>\r\n  <span class=\"text\">\r\n    "
    + alias3(((helper = (helper = helpers.systemName || (depth0 != null ? depth0.systemName : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"systemName","hash":{},"data":data}) : helper)))
    + " reported clear by "
    + alias3(((helper = (helper = helpers.reporterName || (depth0 != null ? depth0.reporterName : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"reporterName","hash":{},"data":data}) : helper)))
    + "\r\n  </span>  \r\n";
},"3":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2=this.escapeExpression, alias3="function";

  return "  <i class=\"fa fa-crosshairs\"></i>\r\n  <span class=\"text\">\r\n    "
    + alias2((helpers.reported || (depth0 && depth0.reported) || alias1).call(depth0,(depth0 != null ? depth0.pilots : depth0),{"name":"reported","hash":{},"data":data}))
    + " reported in "
    + alias2(((helper = (helper = helpers.systemName || (depth0 != null ? depth0.systemName : depth0)) != null ? helper : alias1),(typeof helper === alias3 ? helper.call(depth0,{"name":"systemName","hash":{},"data":data}) : helper)))
    + " by "
    + alias2(((helper = (helper = helpers.reporterName || (depth0 != null ? depth0.reporterName : depth0)) != null ? helper : alias1),(typeof helper === alias3 ? helper.call(depth0,{"name":"reporterName","hash":{},"data":data}) : helper)))
    + "\r\n  </span>  \r\n";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<div class=\"event "
    + alias3(((helper = (helper = helpers.type || (depth0 != null ? depth0.type : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"type","hash":{},"data":data}) : helper)))
    + "\" data-key=\""
    + alias3(((helper = (helper = helpers.key || (depth0 != null ? depth0.key : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"key","hash":{},"data":data}) : helper)))
    + "\">\r\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.clear : depth0),{"name":"if","hash":{},"fn":this.program(1, data, 0),"inverse":this.program(3, data, 0),"data":data})) != null ? stack1 : "")
    + "  <div class=\"right\">\r\n    <span class=\"time\">"
    + alias3(((helper = (helper = helpers.time || (depth0 != null ? depth0.time : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"time","hash":{},"data":data}) : helper)))
    + "</span>\r\n  </div>\r\n</div>\r\n";
},"useData":true});
this["Templates"]["scan"] = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "      <div class=\"result\">\r\n        <span class=\"ship-class\">"
    + alias3(((helper = (helper = helpers.count || (depth0 != null ? depth0.count : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"count","hash":{},"data":data}) : helper)))
    + "x <b>"
    + alias3(((helper = (helper = helpers.shipClass || (depth0 != null ? depth0.shipClass : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"shipClass","hash":{},"data":data}) : helper)))
    + "</b></span>\r\n      </div>\r\n";
},"3":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "      <div class=\"result\">\r\n        <span class=\"ship-type\" onclick=\"ScanList.toggleCollapse(this)\">"
    + alias3(((helper = (helper = helpers.count || (depth0 != null ? depth0.count : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"count","hash":{},"data":data}) : helper)))
    + "x <b>"
    + alias3(((helper = (helper = helpers.shipType || (depth0 != null ? depth0.shipType : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"shipType","hash":{},"data":data}) : helper)))
    + "</b></span>\r\n\r\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.details : depth0),{"name":"each","hash":{},"fn":this.program(4, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "      </div>\r\n";
},"4":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "        <div class=\"details-container collapsible\">\r\n          <span class=\"ship-name\">"
    + alias3(((helper = (helper = helpers.shipName || (depth0 != null ? depth0.shipName : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"shipName","hash":{},"data":data}) : helper)))
    + "</span>\r\n          <span class=\"distance\">"
    + alias3(((helper = (helper = helpers.distance || (depth0 != null ? depth0.distance : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"distance","hash":{},"data":data}) : helper)))
    + "</span>\r\n        </div>\r\n";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<div class=\"scan\">\r\n  <table class=\"description\" onclick=\"ScanList.toggleCollapse(this);\">\r\n    <tr>\r\n      <td class=\"reported-by\"><a href=\"javascript:CCPEVE.showInfo(1377, "
    + alias3(((helper = (helper = helpers.reporterId || (depth0 != null ? depth0.reporterId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"reporterId","hash":{},"data":data}) : helper)))
    + ");\">"
    + alias3(((helper = (helper = helpers.reporterName || (depth0 != null ? depth0.reporterName : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"reporterName","hash":{},"data":data}) : helper)))
    + "</a> shared scan results</td>\r\n      <td class=\"system\"><a href=\"javascript:CCPEVE.showInfo(5,"
    + alias3(((helper = (helper = helpers.systemId || (depth0 != null ? depth0.systemId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"systemId","hash":{},"data":data}) : helper)))
    + ");\">"
    + alias3(((helper = (helper = helpers.systemName || (depth0 != null ? depth0.systemName : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"systemName","hash":{},"data":data}) : helper)))
    + "</a></td>\r\n      <td class=\"actions\">\r\n        <a title=\"Permalink\" target=\"_blank\" href=\"/scans/"
    + alias3(((helper = (helper = helpers._id || (depth0 != null ? depth0._id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"_id","hash":{},"data":data}) : helper)))
    + "/\"><i class=\"fa fa-external-link-square\" title=\"Scan Permalink\"></i></a>\r\n      </td>\r\n      <td class=\"reported-at\">"
    + alias3(((helper = (helper = helpers.time || (depth0 != null ? depth0.time : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"time","hash":{},"data":data}) : helper)))
    + "</td>\r\n    </tr>\r\n  </table>\r\n  <div class=\"results-container collapsible\">\r\n    <ul class=\"actions\">\r\n      <li><a class=\"btn\" onclick=\"scanFilter(this, 'grid');\">On Grid</a></li>\r\n      <li><a class=\"btn\" onclick=\"scanFilter(this, 'offgrid');\">Off Grid</a></li>\r\n    </ul>\r\n    <div class=\"scan-classes\">\r\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.shipClasses : depth0),{"name":"each","hash":{},"fn":this.program(1, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    </div>\r\n    <div class=\"type-classes\">\r\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.shipTypes : depth0),{"name":"each","hash":{},"fn":this.program(3, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    </div>\r\n  </div>\r\n</div>\r\n";
},"useData":true});
this["Templates"]["start"] = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    return "<i class=\"close fa fa-times fa-2x\" onClick=\"UIPanels.hidePanel()\"></i>";
},"3":function(depth0,helpers,partials,data) {
    return "<i class=\"fa fa-"
    + this.escapeExpression((helpers.ui_icon || (depth0 && depth0.ui_icon) || helpers.helperMissing).call(depth0,(depth0 != null ? depth0.icon : depth0),{"name":"ui_icon","hash":{},"data":data}))
    + " fa-3x\"></i>";
},"5":function(depth0,helpers,partials,data) {
    var helper;

  return "<img src=\"/images/"
    + this.escapeExpression(((helper = (helper = helpers.image || (depth0 != null ? depth0.image : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"image","hash":{},"data":data}) : helper)))
    + "\" alt=\"Panel image\" />";
},"7":function(depth0,helpers,partials,data) {
    return "<img id=\"logo\" src=\"/images/panel-logo.png\" alt=\"Standing Fleet\" />";
},"9":function(depth0,helpers,partials,data) {
    var stack1, helper;

  return "<div class=\"text title\">"
    + ((stack1 = ((helper = (helper = helpers.title || (depth0 != null ? depth0.title : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"title","hash":{},"data":data}) : helper))) != null ? stack1 : "")
    + "</div>";
},"11":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "      <tr>\r\n        <td>\r\n          <a href=\"/join/"
    + alias3(((helper = (helper = helpers.key || (depth0 != null ? depth0.key : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"key","hash":{},"data":data}) : helper)))
    + "\" title=\""
    + alias3(((helper = (helper = helpers.key || (depth0 != null ? depth0.key : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"key","hash":{},"data":data}) : helper)))
    + "\">\r\n            "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.name : depth0),{"name":"if","hash":{},"fn":this.program(12, data, 0),"inverse":this.program(14, data, 0),"data":data})) != null ? stack1 : "")
    + "\r\n          </a>\r\n        </td>\r\n        <td>"
    + alias3(((helper = (helper = helpers.description || (depth0 != null ? depth0.description : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"description","hash":{},"data":data}) : helper)))
    + "</td>\r\n        <td>\r\n          "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.has_password : depth0),{"name":"if","hash":{},"fn":this.program(16, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n          "
    + alias3((helpers.format_ts || (depth0 && depth0.format_ts) || alias1).call(depth0,(depth0 != null ? depth0.ts : depth0),{"name":"format_ts","hash":{},"data":data}))
    + "</td>\r\n      </tr>\r\n";
},"12":function(depth0,helpers,partials,data) {
    var helper;

  return this.escapeExpression(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"name","hash":{},"data":data}) : helper)));
},"14":function(depth0,helpers,partials,data) {
    var helper;

  return this.escapeExpression(((helper = (helper = helpers.key || (depth0 != null ? depth0.key : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"key","hash":{},"data":data}) : helper)));
},"16":function(depth0,helpers,partials,data) {
    return "<i class=\"fa fa-lock\"></i>";
},"18":function(depth0,helpers,partials,data) {
    var stack1, helper;

  return "  <div class=\"text footer\">"
    + ((stack1 = ((helper = (helper = helpers.footer || (depth0 != null ? depth0.footer : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"footer","hash":{},"data":data}) : helper))) != null ? stack1 : "")
    + "</div>\r\n";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, helper;

  return "<div class=\"panel "
    + this.escapeExpression(((helper = (helper = helpers.type || (depth0 != null ? depth0.type : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"type","hash":{},"data":data}) : helper)))
    + "\">\r\n  <div class=\"header\">\r\n    "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.closeable : depth0),{"name":"if","hash":{},"fn":this.program(1, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n    "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.icon : depth0),{"name":"if","hash":{},"fn":this.program(3, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n    "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.image : depth0),{"name":"if","hash":{},"fn":this.program(5, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n    "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.logo : depth0),{"name":"if","hash":{},"fn":this.program(7, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n    "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.title : depth0),{"name":"if","hash":{},"fn":this.program(9, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n  </div>\r\n  \r\n  <!-- <a class=\"button submit-create\" onclick=\"UIPanels.showCreatePanel()\">Create Fleet</a> -->\r\n  \r\n  <h2>Current Fleets</h2>\r\n  <table>\r\n    <thead>\r\n      <tr>\r\n        <th>Name</th>\r\n        <th>Description</th>\r\n        <th>Formed</th>\r\n      </tr>\r\n    </thead>\r\n    <tbody>\r\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.fleets : depth0),{"name":"each","hash":{},"fn":this.program(11, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    </tbody>\r\n  </table>  \r\n  \r\n  <a target=\"_blank\" class=\"button submit-leave\" onclick=\"leaveFleet()\">Leave Fleet</a>\r\n\r\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.footer : depth0),{"name":"if","hash":{},"fn":this.program(18, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "</div>\r\n";
},"useData":true});
this["Templates"]["system_info"] = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    var helper;

  return "    <dt>WH Class</dt>\r\n    <dd class=\"wormhole-class\">C"
    + this.escapeExpression(((helper = (helper = helpers.wormhole_class || (depth0 != null ? depth0.wormhole_class : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"wormhole_class","hash":{},"data":data}) : helper)))
    + "</dd>\r\n    \r\n";
},"3":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "    <dt>Security Class</dt>\r\n    <dd class=\"security-class\">"
    + alias3(((helper = (helper = helpers.security_class || (depth0 != null ? depth0.security_class : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"security_class","hash":{},"data":data}) : helper)))
    + "</dd>\r\n\r\n    <dt>Security Level</dt>\r\n    <dd class=\"security-level\">"
    + alias3(((helper = (helper = helpers.security || (depth0 != null ? depth0.security : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"security","hash":{},"data":data}) : helper)))
    + "</dd>\r\n";
},"5":function(depth0,helpers,partials,data) {
    var stack1;

  return "    <dt>Hostiles</dt>\r\n    <dd class=\"hostiles\">\r\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.hostiles : depth0),{"name":"each","hash":{},"fn":this.program(6, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    </dd>\r\n";
},"6":function(depth0,helpers,partials,data) {
    var stack1, helper;

  return "        <div class=\"hostile\" onClick=\"UIPanels.updateHostileDetailsPanel('"
    + this.escapeExpression(((helper = (helper = helpers.characterId || (depth0 != null ? depth0.characterId : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"characterId","hash":{},"data":data}) : helper)))
    + "');\">\r\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.is_faded : depth0),{"name":"if","hash":{},"fn":this.program(7, data, 0),"inverse":this.program(9, data, 0),"data":data})) != null ? stack1 : "")
    + "        </div>\r\n";
},"7":function(depth0,helpers,partials,data) {
    var helper;

  return "          <i class=\"fa fa-clock-o\" title=\"Faded\"></i> "
    + this.escapeExpression(((helper = (helper = helpers.characterName || (depth0 != null ? depth0.characterName : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"characterName","hash":{},"data":data}) : helper)))
    + "\r\n";
},"9":function(depth0,helpers,partials,data) {
    var helper;

  return "          <i class=\"fa fa-fighter-jet\" title=\"Active\"></i> "
    + this.escapeExpression(((helper = (helper = helpers.characterName || (depth0 != null ? depth0.characterName : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"characterName","hash":{},"data":data}) : helper)))
    + "\r\n";
},"11":function(depth0,helpers,partials,data) {
    var stack1;

  return "    <dt>Gates</dt>\r\n    <dd class=\"gates\">\r\n      <ul>\r\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.jumps : depth0),{"name":"each","hash":{},"fn":this.program(12, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "      </ul>\r\n    </dd>\r\n";
},"12":function(depth0,helpers,partials,data) {
    var helper;

  return "        <li><i class=\"fa fa-chevron-right\"></i>"
    + this.escapeExpression(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"name","hash":{},"data":data}) : helper)))
    + "</li>\r\n";
},"14":function(depth0,helpers,partials,data) {
    var stack1;

  return "    <dt>Advisories<dt>\r\n    <dd class=\"advisories\">\r\n      <ul>\r\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.active_advisories : depth0),{"name":"each","hash":{},"fn":this.program(15, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "      </ul>\r\n    </dd>\r\n";
},"15":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2=this.escapeExpression;

  return "        <li><i class=\"fa fa-"
    + alias2((helpers.ui_icon || (depth0 && depth0.ui_icon) || alias1).call(depth0,(depth0 != null ? depth0.type : depth0),{"name":"ui_icon","hash":{},"data":data}))
    + "\"></i> "
    + alias2(((helper = (helper = helpers.type || (depth0 != null ? depth0.type : depth0)) != null ? helper : alias1),(typeof helper === "function" ? helper.call(depth0,{"name":"type","hash":{},"data":data}) : helper)))
    + "</li>\r\n";
},"17":function(depth0,helpers,partials,data) {
    var stack1;

  return "  <h4 class=\"report-advisory\">Report Advisory</h4>\r\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.advisories : depth0),{"name":"each","hash":{},"fn":this.program(18, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "");
},"18":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "  <a class=\"btn "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.present : depth0),{"name":"if","hash":{},"fn":this.program(19, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\" onclick=\"reportAdvisory(this, '"
    + alias3(((helper = (helper = helpers.systemId || (depth0 != null ? depth0.systemId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"systemId","hash":{},"data":data}) : helper)))
    + "', '"
    + alias3(((helper = (helper = helpers.type || (depth0 != null ? depth0.type : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"type","hash":{},"data":data}) : helper)))
    + "')\" title=\""
    + alias3(((helper = (helper = helpers.type || (depth0 != null ? depth0.type : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"type","hash":{},"data":data}) : helper)))
    + "\"><i class=\"fa fa-"
    + alias3((helpers.ui_icon || (depth0 && depth0.ui_icon) || alias1).call(depth0,(depth0 != null ? depth0.type : depth0),{"name":"ui_icon","hash":{},"data":data}))
    + "\"></i></a>\r\n";
},"19":function(depth0,helpers,partials,data) {
    return "present";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<div class=\"details\">\r\n  <h4>Solar System Details</h4>\r\n  <dl>\r\n    <dt>System</dt>\r\n    <dd class=\"system\">"
    + alias3(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"name","hash":{},"data":data}) : helper)))
    + "</dd>\r\n\r\n    <dt>Region</dt>\r\n    <dd class=\"region\">"
    + alias3(((helper = (helper = helpers.region || (depth0 != null ? depth0.region : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"region","hash":{},"data":data}) : helper)))
    + "</dd>\r\n\r\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.wormhole_class : depth0),{"name":"if","hash":{},"fn":this.program(1, data, 0),"inverse":this.program(3, data, 0),"data":data})) != null ? stack1 : "")
    + "    \r\n    <dt>Last Report</dt>\r\n    <dd class=\"last-report\">"
    + alias3(((helper = (helper = helpers.last_report || (depth0 != null ? depth0.last_report : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"last_report","hash":{},"data":data}) : helper)))
    + "</dd>\r\n\r\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.hostiles : depth0),{"name":"if","hash":{},"fn":this.program(5, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    \r\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.jumps : depth0),{"name":"if","hash":{},"fn":this.program(11, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.active_advisories : depth0),{"name":"if","hash":{},"fn":this.program(14, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "  </dl>\r\n\r\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.allow_report : depth0),{"name":"if","hash":{},"fn":this.program(17, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n  <h4 class=\"external\">External Resources</h4>  \r\n  <a class=\"btn\" target=\"_blank\" href=\"http://evemaps.dotlan.net/map/"
    + alias3(((helper = (helper = helpers.region || (depth0 != null ? depth0.region : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"region","hash":{},"data":data}) : helper)))
    + "/"
    + alias3(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"name","hash":{},"data":data}) : helper)))
    + "#const\">\r\n    Dotlan\r\n    <i class=\"fa fa-external-link-square\"></i>\r\n  </a>\r\n</div>\r\n";
},"useData":true});
this["Templates"]["wormhole_link_info"] = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    var stack1;

  return "    <dd class=\"signature\">"
    + this.escapeExpression(this.lambda(((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.signature : stack1), depth0))
    + "</dd>\r\n";
},"3":function(depth0,helpers,partials,data) {
    return "    <dd class=\"signature\">Not Scanned</dd>\r\n";
},"5":function(depth0,helpers,partials,data) {
    var stack1;

  return "    <dt>Jump Type</dt>\r\n    <dd class=\"code\">"
    + this.escapeExpression(this.lambda(((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.code : stack1), depth0))
    + "</dd>\r\n";
},"7":function(depth0,helpers,partials,data) {
    var stack1;

  return "    <dd class=\"signature\">"
    + this.escapeExpression(this.lambda(((stack1 = ((stack1 = (depth0 != null ? depth0.link_b : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.signature : stack1), depth0))
    + "</dd>\r\n";
},"9":function(depth0,helpers,partials,data) {
    var stack1;

  return "    <dt>Jump Type</dt>\r\n    <dd class=\"code\">"
    + this.escapeExpression(this.lambda(((stack1 = ((stack1 = (depth0 != null ? depth0.link_b : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.code : stack1), depth0))
    + "</dd>\r\n";
},"11":function(depth0,helpers,partials,data) {
    var stack1;

  return "    <dt>Lifespan</dt>\r\n    <dd class=\"lifespan\">"
    + this.escapeExpression(this.lambda(((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.lifespan_estimate : stack1), depth0))
    + "</dd>\r\n";
},"13":function(depth0,helpers,partials,data) {
    var stack1;

  return "    <dt>Jump Limit</dt>\r\n    <dd class=\"jump-mass\">"
    + this.escapeExpression((helpers.add_commas || (depth0 && depth0.add_commas) || helpers.helperMissing).call(depth0,((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.jump_mass : stack1),{"name":"add_commas","hash":{},"data":data}))
    + " KG</dd>\r\n";
},"15":function(depth0,helpers,partials,data) {
    var stack1;

  return "    <dt>Mass Left</dt>\r\n    <dd class=\"mass\">"
    + this.escapeExpression((helpers.add_commas || (depth0 && depth0.add_commas) || helpers.helperMissing).call(depth0,((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.mass_total : stack1),{"name":"add_commas","hash":{},"data":data}))
    + " KG</dd>\r\n";
},"17":function(depth0,helpers,partials,data) {
    var stack1;

  return "    <dt>Allowed Ships</dt>\r\n    <dd class=\"permitted-ships\">\r\n"
    + ((stack1 = helpers.each.call(depth0,((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.permitted_ships : stack1),{"name":"each","hash":{},"fn":this.program(18, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    </dd>\r\n";
},"18":function(depth0,helpers,partials,data) {
    var alias1=this.lambda, alias2=this.escapeExpression;

  return "      <img src=\"/images/ship-icons/"
    + alias2(alias1(depth0, depth0))
    + ".png\" title=\""
    + alias2(alias1(depth0, depth0))
    + "\" alt=\""
    + alias2(alias1(depth0, depth0))
    + "\" />\r\n";
},"20":function(depth0,helpers,partials,data) {
    var stack1, alias1=this.lambda, alias2=this.escapeExpression;

  return "    <dt>Reported By</dt>\r\n    <dd><a href=\"javascript:CCPEVE.showInfo(1377, "
    + alias2(alias1(((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.reporterId : stack1), depth0))
    + ");\">"
    + alias2(alias1(((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.reporterName : stack1), depth0))
    + "</a></dd>\r\n";
},"22":function(depth0,helpers,partials,data) {
    var stack1;

  return "    <h4>Logged Traversals</h4>\r\n    <table class=\"traversals\">\r\n"
    + ((stack1 = helpers.each.call(depth0,((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.traversals : stack1),{"name":"each","hash":{},"fn":this.program(23, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    </table>\r\n";
},"23":function(depth0,helpers,partials,data) {
    var alias1=this.lambda, alias2=this.escapeExpression, alias3=helpers.helperMissing;

  return "    <tr>\r\n      <td class=\"fleet\">"
    + alias2(alias1((depth0 != null ? depth0.fleet_name : depth0), depth0))
    + " | FC: "
    + alias2(alias1((depth0 != null ? depth0.fc_characterName : depth0), depth0))
    + "</td>\r\n      <td class=\"timestamp\">"
    + alias2((helpers.format_ts_short || (depth0 && depth0.format_ts_short) || alias3).call(depth0,(depth0 != null ? depth0.ts : depth0),{"name":"format_ts_short","hash":{},"data":data}))
    + "</td>\r\n    </tr>\r\n    <tr>\r\n      <td colspan=\"2\" class=\"mass\">"
    + alias2((helpers.add_commas || (depth0 && depth0.add_commas) || alias3).call(depth0,(depth0 != null ? depth0.mass : depth0),{"name":"add_commas","hash":{},"data":data}))
    + " KG</td>\r\n    </tr>\r\n";
},"25":function(depth0,helpers,partials,data) {
    var stack1, alias1=this.lambda, alias2=this.escapeExpression;

  return "    <h4>Update Link Actions</h4>\r\n"
    + ((stack1 = helpers.unless.call(depth0,(depth0 != null ? depth0.clear_only : depth0),{"name":"unless","hash":{},"fn":this.program(26, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    \r\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.fc_only : depth0),{"name":"if","hash":{},"fn":this.program(28, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n    <a class=\"btn btn-danger\" onclick=\"updateWormholeLink(this, '"
    + alias2(alias1(((stack1 = ((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.source : stack1)) != null ? stack1.system : stack1)) != null ? stack1.id : stack1), depth0))
    + "', '"
    + alias2(alias1(((stack1 = ((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.target : stack1)) != null ? stack1.system : stack1)) != null ? stack1.id : stack1), depth0))
    + "', 'Wormhole collapsed')\" title=\"Close\">\r\n      <i class=\"fa fa-"
    + alias2((helpers.ui_icon || (depth0 && depth0.ui_icon) || helpers.helperMissing).call(depth0,"close",{"name":"ui_icon","hash":{},"data":data}))
    + "\"></i> Clear\r\n    </a>  \r\n";
},"26":function(depth0,helpers,partials,data) {
    var stack1, alias1=this.lambda, alias2=this.escapeExpression;

  return "    <a class=\"btn btn-info\" onclick=\"UIPanels.updateWormholeLinkPanel(this, '"
    + alias2(alias1(((stack1 = ((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.source : stack1)) != null ? stack1.system : stack1)) != null ? stack1.id : stack1), depth0))
    + "', '"
    + alias2(alias1(((stack1 = ((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.target : stack1)) != null ? stack1.system : stack1)) != null ? stack1.id : stack1), depth0))
    + "')\" title=\"Update\">\r\n      <i class=\"fa fa-"
    + alias2((helpers.ui_icon || (depth0 && depth0.ui_icon) || helpers.helperMissing).call(depth0,"info",{"name":"ui_icon","hash":{},"data":data}))
    + "\"></i> Update\r\n    </a>\r\n";
},"28":function(depth0,helpers,partials,data) {
    var stack1, alias1=this.lambda, alias2=this.escapeExpression;

  return "    <a class=\"btn btn-info\" onclick=\"UIPanels.updateWormholeTraversalPanel(this, '"
    + alias2(alias1(((stack1 = ((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.source : stack1)) != null ? stack1.system : stack1)) != null ? stack1.id : stack1), depth0))
    + "', '"
    + alias2(alias1(((stack1 = ((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.target : stack1)) != null ? stack1.system : stack1)) != null ? stack1.id : stack1), depth0))
    + "')\" title=\"Traversal\">\r\n      <i class=\"fa fa-"
    + alias2((helpers.ui_icon || (depth0 && depth0.ui_icon) || helpers.helperMissing).call(depth0,"traversal",{"name":"ui_icon","hash":{},"data":data}))
    + "\"></i> Log Traversal\r\n    </a>\r\n";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, alias1=this.lambda, alias2=this.escapeExpression, alias3=helpers.helperMissing;

  return "<div class=\"wormhole-link-details\">\r\n  <h4>"
    + alias2(alias1(((stack1 = ((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.source : stack1)) != null ? stack1.system : stack1)) != null ? stack1.name : stack1), depth0))
    + " <i class=\"fa fa-long-arrow-right\"></i> "
    + alias2(alias1(((stack1 = ((stack1 = ((stack1 = (depth0 != null ? depth0.link_b : depth0)) != null ? stack1.source : stack1)) != null ? stack1.system : stack1)) != null ? stack1.name : stack1), depth0))
    + "</h4>\r\n  <dl>\r\n    <dt>Signature ID</dt>\r\n"
    + ((stack1 = helpers['if'].call(depth0,((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.signature : stack1),{"name":"if","hash":{},"fn":this.program(1, data, 0),"inverse":this.program(3, data, 0),"data":data})) != null ? stack1 : "")
    + "    \r\n"
    + ((stack1 = helpers['if'].call(depth0,((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.code : stack1),{"name":"if","hash":{},"fn":this.program(5, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "  </dl>\r\n  \r\n  <h4>"
    + alias2(alias1(((stack1 = ((stack1 = ((stack1 = (depth0 != null ? depth0.link_b : depth0)) != null ? stack1.source : stack1)) != null ? stack1.system : stack1)) != null ? stack1.name : stack1), depth0))
    + " <i class=\"fa fa-long-arrow-right\"></i> "
    + alias2(alias1(((stack1 = ((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.source : stack1)) != null ? stack1.system : stack1)) != null ? stack1.name : stack1), depth0))
    + "</h4>\r\n  <dl>\r\n    <dt>Signature ID</dt>\r\n"
    + ((stack1 = helpers['if'].call(depth0,((stack1 = ((stack1 = (depth0 != null ? depth0.link_b : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.signature : stack1),{"name":"if","hash":{},"fn":this.program(7, data, 0),"inverse":this.program(3, data, 0),"data":data})) != null ? stack1 : "")
    + "    \r\n"
    + ((stack1 = helpers['if'].call(depth0,((stack1 = ((stack1 = (depth0 != null ? depth0.link_b : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.code : stack1),{"name":"if","hash":{},"fn":this.program(9, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "  </dl>\r\n  \r\n  <h4>Jump Estimates</h4>\r\n  <dl>\r\n"
    + ((stack1 = helpers['if'].call(depth0,((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.lifespan_estimate : stack1),{"name":"if","hash":{},"fn":this.program(11, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    \r\n"
    + ((stack1 = helpers['if'].call(depth0,((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.jump_mass : stack1),{"name":"if","hash":{},"fn":this.program(13, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    \r\n"
    + ((stack1 = helpers['if'].call(depth0,((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.mass_total : stack1),{"name":"if","hash":{},"fn":this.program(15, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n"
    + ((stack1 = helpers['if'].call(depth0,((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.mass_total : stack1),{"name":"if","hash":{},"fn":this.program(17, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    \r\n    <dt>Expires</dt>\r\n    <dd class=\"expires-on\">"
    + alias2((helpers.format_ts || (depth0 && depth0.format_ts) || alias3).call(depth0,((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.expires_on : stack1),{"name":"format_ts","hash":{},"data":data}))
    + "</dd>\r\n    \r\n    <dt>Last Updated</dt>\r\n    <dd class=\"updated-at\">"
    + alias2((helpers.format_ts || (depth0 && depth0.format_ts) || alias3).call(depth0,((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.updated_at : stack1),{"name":"format_ts","hash":{},"data":data}))
    + "</dd>\r\n    \r\n"
    + ((stack1 = helpers['if'].call(depth0,((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.reporterId : stack1),{"name":"if","hash":{},"fn":this.program(20, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "  </dl>\r\n\r\n"
    + ((stack1 = helpers['if'].call(depth0,((stack1 = ((stack1 = (depth0 != null ? depth0.link_a : depth0)) != null ? stack1.wormhole_data : stack1)) != null ? stack1.traversals : stack1),{"name":"if","hash":{},"fn":this.program(22, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n"
    + ((stack1 = helpers.unless.call(depth0,(depth0 != null ? depth0.read_only : depth0),{"name":"unless","hash":{},"fn":this.program(25, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "  \r\n  "
    + alias2(helpers.log.call(depth0,depth0,{"name":"log","hash":{},"data":data}))
    + "\r\n</div>\r\n";
},"useData":true});
this["Templates"]["wormhole_update_panel"] = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    return "<i class=\"close fa fa-times fa-2x\" onClick=\"UIPanels.hidePanel()\"></i>";
},"3":function(depth0,helpers,partials,data) {
    return "<i class=\"fa fa-"
    + this.escapeExpression((helpers.ui_icon || (depth0 && depth0.ui_icon) || helpers.helperMissing).call(depth0,(depth0 != null ? depth0.icon : depth0),{"name":"ui_icon","hash":{},"data":data}))
    + " fa-3x\"></i>";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, alias1=this.lambda, alias2=this.escapeExpression;

  return "<div class=\"panel wormhole-update\">\r\n  <div class=\"header\">\r\n    "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.closeable : depth0),{"name":"if","hash":{},"fn":this.program(1, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n    "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.icon : depth0),{"name":"if","hash":{},"fn":this.program(3, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n    <div class=\"text title\">Update Wormhole Link</div>\r\n  </div>\r\n  <div class=\"content\">\r\n    <div class=\"form\">\r\n      <input id=\"to\" type=\"hidden\" value=\""
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.to : depth0)) != null ? stack1.id : stack1), depth0))
    + "\" />\r\n      <input id=\"from\" type=\"hidden\" value=\""
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.from : depth0)) != null ? stack1.id : stack1), depth0))
    + "\" />\r\n\r\n      <span class=\"legend\">"
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.from : depth0)) != null ? stack1.name : stack1), depth0))
    + " <i class=\"fa fa-long-arrow-right\"></i> "
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.to : depth0)) != null ? stack1.name : stack1), depth0))
    + "</span>\r\n      <div class=\"group inline\">\r\n        <label for=\"sig-a\" autofocus>Signature ID</label>\r\n        <input id=\"sig-a\" max=\"7\" type=\"text\" />\r\n      </div>\r\n      \r\n      <div class=\"group inline\">\r\n        <label for=\"type-a\">Wormhole Code</label>\r\n        <input id=\"type-a\" max=\"4\" type=\"text\" />\r\n      </div>\r\n      \r\n      <span class=\"legend\">"
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.to : depth0)) != null ? stack1.name : stack1), depth0))
    + " <i class=\"fa fa-long-arrow-right\"></i> "
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.from : depth0)) != null ? stack1.name : stack1), depth0))
    + "</span>\r\n      <div class=\"group inline\">\r\n        <label for=\"sig-b\">Signature ID</label>\r\n        <input id=\"sig-b\" max=\"7\" type=\"text\" />\r\n      </div>\r\n      \r\n      <div class=\"group inline\">\r\n        <label for=\"type-b\">Wormhole Code</label>\r\n        <input id=\"type-b\" max=\"4\" type=\"text\" />\r\n      </div>\r\n\r\n      <span class=\"legend\">Wormhole Info Text</span>\r\n      <textarea id=\"wormhole-info\" class=\"textinput wormhole-info\"></textarea>\r\n\r\n      <div class=\"submit\">\r\n        <a target=\"_blank\" class=\"button\" onClick=\"updateWormholeLink(this, "
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.from : depth0)) != null ? stack1.id : stack1), depth0))
    + ", "
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.to : depth0)) != null ? stack1.id : stack1), depth0))
    + ")\">Update Jump Link</a>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n";
},"useData":true});
this["Templates"]["wormhole_update_traversal"] = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    return "<i class=\"close fa fa-times fa-2x\" onClick=\"UIPanels.hidePanel()\"></i>";
},"3":function(depth0,helpers,partials,data) {
    return "<i class=\"fa fa-"
    + this.escapeExpression((helpers.ui_icon || (depth0 && depth0.ui_icon) || helpers.helperMissing).call(depth0,(depth0 != null ? depth0.icon : depth0),{"name":"ui_icon","hash":{},"data":data}))
    + " fa-3x\"></i>";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, alias1=this.lambda, alias2=this.escapeExpression;

  return "<div class=\"panel wormhole-update\">\r\n  <div class=\"header\">\r\n    "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.closeable : depth0),{"name":"if","hash":{},"fn":this.program(1, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n    "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.icon : depth0),{"name":"if","hash":{},"fn":this.program(3, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "\r\n    <div class=\"text title\">Log Wormhole Traversal</div>\r\n  </div>\r\n  <div class=\"content\">\r\n    <h3>"
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.from : depth0)) != null ? stack1.name : stack1), depth0))
    + " <i class=\"fa fa-arrows-h\"></i> "
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.to : depth0)) != null ? stack1.name : stack1), depth0))
    + "</h3>\r\n    <div class=\"form\">\r\n      <input id=\"to\" type=\"hidden\" value=\""
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.to : depth0)) != null ? stack1.id : stack1), depth0))
    + "\" />\r\n      <input id=\"from\" type=\"hidden\" value=\""
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.from : depth0)) != null ? stack1.id : stack1), depth0))
    + "\" />\r\n\r\n      <div class=\"group inline\">\r\n        <label for=\"traversal-mass\" autofocus>Fleet Mass</label>\r\n        <input id=\"traversal-mass\" type=\"text\" placeholder=\"XX,XXX,XXX\" />\r\n      </div>\r\n      \r\n      <div class=\"group inline\">\r\n        <label for=\"traversal-fleet\">Fleet Name</label>\r\n        <input id=\"traversal-fleet\" type=\"text\" />\r\n      </div>\r\n      \r\n      <div class=\"group inline\">\r\n        <label for=\"traversal-fc\">FC Name</label>\r\n        <input id=\"traversal-fc\" type=\"text\" />\r\n      </div>\r\n\r\n      <div class=\"submit\">\r\n        <a target=\"_blank\" class=\"button\" onClick=\"updateWormholeTraversal(this, "
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.from : depth0)) != null ? stack1.id : stack1), depth0))
    + ", "
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.to : depth0)) != null ? stack1.id : stack1), depth0))
    + ")\">Log Traversal</a>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n";
},"useData":true});